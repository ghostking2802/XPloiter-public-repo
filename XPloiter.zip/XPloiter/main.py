# File: main.py
from PyQt6 import QtCore, QtGui, QtWidgets
import os
import psutil  # Used to check Ethernet connection status
import socket  # Add this import at the top for AF_INET and AF_INET6
from PyQt6.QtCore import QTimer
from PyQt6.QtCore import QThread, QObject, pyqtSignal
import subprocess
from PyQt6.QtGui import QFont
from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtCore import QTimer, QThread, QObject, pyqtSignal
from PyQt6.QtGui import QFont, QPixmap
import re
import re
import subprocess
from PyQt6.QtCore import QTimer, QThread, pyqtSignal
from PyQt6.QtWidgets import QMessageBox
from PyQt6.QtGui import QPixmap, QImage
from PyQt6.QtCore import QRect
import subprocess
import time
import os
import re
from datetime import datetime
from PyQt6 import QtCore, QtGui, QtWidgets
import os
import time
from ui import Ui_MainWindow
import sys
import subprocess
from PyQt6 import QtWidgets, QtCore
from PyQt6.QtGui import QFont
from PyQt6 import QtWidgets, QtCore, QtGui
import subprocess
import subprocess
from PyQt6 import QtWidgets, QtCore
from PyQt6.QtGui import QFont
import datetime
import subprocess
from PyQt6 import QtWidgets, QtCore
from PyQt6.QtGui import QFont
from PyQt6 import QtWidgets, QtCore, QtGui
from PyQt6.QtWidgets import QTreeWidgetItem, QMessageBox
import os
import json
import subprocess
from PyQt6 import QtWidgets, QtCore
from PyQt6.QtGui import QFont
import subprocess
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtWidgets import QMessageBox
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6 import QtWidgets
import os
import subprocess
from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtWidgets import QMessageBox, QTreeWidgetItem
from datetime import datetime
from PyQt6 import QtWidgets, QtGui, QtCore
import time
import itertools
import itertools
import os
from PyQt6 import QtWidgets, QtGui, QtCore
from PyQt6.QtGui import QFont
# Initialize readers
import serial
import os
from PyQt6 import QtWidgets, QtGui, QtCore
from PyQt6.QtGui import QFont
from PyQt6.QtCore import QThread, pyqtSignal
import itertools
from PyQt6.QtCore import QThread, pyqtSignal
import itertools
from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtCore import QPropertyAnimation, QRect, QEasingCurve, pyqtProperty
from PyQt6.QtGui import QColor, QPainter, QPen
from PyQt6.QtWidgets import QWidget, QPushButton
import os
from PyQt6.QtCore import pyqtSlot
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication
# Enable touch event support globally
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication

QApplication.setAttribute(Qt.ApplicationAttribute.AA_SynthesizeTouchForUnhandledMouseEvents, True)

import json
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtCore import QPropertyAnimation, QEasingCurve, QRect
from PyQt6.QtWidgets import QGraphicsOpacityEffect, QVBoxLayout
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel, QPushButton
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, pyqtProperty, QRectF
from PyQt6.QtGui import QPainter, QBrush, QColor
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel, QGraphicsOpacityEffect
from PyQt6.QtCore import QPropertyAnimation
from PyQt6.QtWidgets import QPushButton
from PyQt6.QtCore import QPropertyAnimation, QEasingCurve, pyqtProperty
from PyQt6.QtGui import QColor, QPainter, QPen
from PyQt6.QtWidgets import QTextEdit
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QTextEdit
from PyQt6.QtCore import Qt, QEvent, QPointF
class TouchScrollableTextEdit(QTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._last_touch_position = None  # Store the last touch position for scrolling

    def event(self, event):
        """Handle touch events for smooth scrolling."""
        if event.type() == QEvent.Type.TouchBegin:
            # Capture the starting touch position
            self._last_touch_position = event.touchPoints()[0].pos()
            return True

        elif event.type() == QEvent.Type.TouchUpdate:
            if self._last_touch_position is not None:
                # Calculate the movement delta
                current_position = event.touchPoints()[0].pos()
                delta = current_position - self._last_touch_position
                self._last_touch_position = current_position

                # Scroll the QTextEdit based on the delta
                self.verticalScrollBar().setValue(
                    self.verticalScrollBar().value() - delta.y()
                )
            return True

        elif event.type() == QEvent.Type.TouchEnd:
            # Reset the touch position when the user lifts their finger
            self._last_touch_position = None
            return True

        return super().event(event)

    def enable_touch(self):
        """Enable touch events for this widget."""
        self.setAttribute(Qt.WidgetAttribute.WA_AcceptTouchEvents, True)

class FuturisticPushButton(QPushButton):
    def __init__(self, text="", parent=None):
        """
        Initialize a futuristic push button with hover animations.
        """
        super().__init__(text, parent)

        # Colors
        self._hover_color = QColor(50, 150, 250)      # Color on hover
        self._default_color = QColor(30, 30, 30)      # Default color
        self._border_color = QColor(255, 255, 255)    # Border color
        self._current_color = self._default_color     # Active color
        self.__hover_progress = 0.0                   # Animation progress (0.0 to 1.0)

        # Hover animation
        self._hover_animation = QPropertyAnimation(self, b"hover_progress")
        self._hover_animation.setDuration(300)  # Animation duration in ms
        self._hover_animation.setEasingCurve(QEasingCurve.Type.OutCubic)

        # Button appearance
        self.setFixedHeight(50)
        self.setStyleSheet("border: none; color: white; font-size: 16px; font-weight: bold;")

    @pyqtProperty(float)
    def hover_progress(self):
        """
        Property to get or set hover progress for animations.
        """
        return self.__hover_progress

    @hover_progress.setter
    def hover_progress(self, value):
        self.__hover_progress = value  # Update hover progress
        # Blend the current color between default and hover colors
        self._current_color.setRed(
            int(self._default_color.red() + (self._hover_color.red() - self._default_color.red()) * value)
        )
        self._current_color.setGreen(
            int(self._default_color.green() + (self._hover_color.green() - self._default_color.green()) * value)
        )
        self._current_color.setBlue(
            int(self._default_color.blue() + (self._hover_color.blue() - self._default_color.blue()) * value)
        )
        self.update()  # Trigger a repaint

    def enterEvent(self, event):
        """
        Start hover animation when the mouse enters the button.
        """
        self._hover_animation.stop()
        self._hover_animation.setStartValue(self.hover_progress)
        self._hover_animation.setEndValue(1.0)  # Full hover effect
        self._hover_animation.start()
        super().enterEvent(event)

    def leaveEvent(self, event):
        """
        Start reverse hover animation when the mouse leaves the button.
        """
        self._hover_animation.stop()
        self._hover_animation.setStartValue(self.hover_progress)
        self._hover_animation.setEndValue(0.0)  # Reset to default effect
        self._hover_animation.start()
        super().leaveEvent(event)

    def paintEvent(self, event):
        """
        Custom paint event to render the button with rounded corners, border, and text.
        """
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Draw button background
        painter.setBrush(self._current_color)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(self.rect(), 15, 15)

        # Draw border
        pen = QPen(self._border_color, 2)  # Border thickness
        painter.setPen(pen)
        painter.drawRoundedRect(self.rect().adjusted(1, 1, -1, -1), 15, 15)

        # Draw text
        painter.setPen(QColor(255, 255, 255))  # White text color
        painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.text())

class FuturisticLoader(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.angle = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_animation)
        self.timer.start(20)  # Control the speed of the animation
        self.resize(200, 200)
    
    def update_animation(self):
        self.angle += 5  # Increase the rotation angle
        if self.angle >= 360:
            self.angle = 0
        self.update()
    
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Draw futuristic rings
        center = self.rect().center()
        radius = min(self.width(), self.height()) // 2 - 10
        painter.translate(center)
        painter.rotate(self.angle)
        
        for i in range(4):
            painter.setBrush(QBrush(QColor(100 + i * 30, 255 - i * 40, 255 - i * 60)))
            painter.drawEllipse(QRectF(-radius + i * 10, -radius + i * 10, 
                                       (radius - i * 10) * 2, (radius - i * 10) * 2))
            painter.rotate(45)




from PyQt6.QtCore import QThread, pyqtSignal
import subprocess

class ADBCommandWorker(QThread):
    output_signal = pyqtSignal(str, str, str)  # Signal to send output to the main thread

    def __init__(self, command):
        super().__init__()
        self.command = command

    def run(self):
        """Execute the ADB command and emit output signals."""
        try:
            process = subprocess.Popen(
                self.command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            stdout, stderr = process.communicate()

            # Emit stdout
            if stdout:
                self.output_signal.emit(stdout, "black", "normal")

            # Emit stderr
            if stderr:
                self.output_signal.emit(stderr, "red", "bold")

        except Exception as e:
            # Emit error message
            self.output_signal.emit(f"[ERROR] Exception occurred: {str(e)}\n", "red", "bold")

class ADBWorker(QThread):
    output_signal = pyqtSignal(str, str, str)  # Message, Color, Weight

    def __init__(self, command):
        super().__init__()
        self.command = command

    def run(self):
        """Run the ADB command and emit the output."""
        try:
            result = subprocess.run(
                self.command.split(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            if result.stdout:
                self.output_signal.emit(result.stdout, "green", "bold")
            if result.stderr:
                self.output_signal.emit(result.stderr, "red", "bold")
        except Exception as e:
            self.output_signal.emit(f"Error: {str(e)}", "red", "bold")

class ADBFunctionWidget(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.start_adb_check_timer()

    def setup_ui(self):
        # Main horizontal layout
        main_layout = QtWidgets.QHBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)

        # Create sections
        section0 = self.create_section0()
        section1 = self.create_section1()

        # Add sections to the main layout
        main_layout.addWidget(section0, stretch=1)

        # Vertical divider
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.VLine)
        line.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        main_layout.addWidget(line)

        main_layout.addWidget(section1, stretch=1)
        """Set up the main vertical layout for the widget."""


    def create_section0(self):
        """Create section 0 with dynamically generated buttons."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)
        section_layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)

        # Add Android image
        android_label = QtWidgets.QLabel()
        android_pixmap = QtGui.QPixmap(self.icon_path("adb.png")).scaled(
            200, 200, QtCore.Qt.AspectRatioMode.KeepAspectRatio
        )
        android_label.setPixmap(android_pixmap)
        android_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        section_layout.addWidget(android_label, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        # Horizontal layout for status and indicator
        status_layout = QtWidgets.QHBoxLayout()
        self.adb_status_label = QtWidgets.QLabel("Checking ADB connection...")
        self.adb_status_label.setStyleSheet("font: bold 14px 'Consolas'; color: #00FFCC;")
        status_layout.addWidget(self.adb_status_label)

        self.adb_indicator_label = QtWidgets.QLabel()
        self.adb_indicator_label.setFixedSize(20, 20)
        self.adb_indicator_label.setStyleSheet("background-color: red; border-radius: 10px;")
        status_layout.addWidget(self.adb_indicator_label)

        section_layout.addLayout(status_layout)

        # Add device list dropdown
        self.device_list = QtWidgets.QComboBox()
        self.device_list.setStyleSheet("""
            QComboBox {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
                border-radius: 5px;
            }
            QComboBox QAbstractItemView {
                background-color: #000000;
                color: #FFFFFF;
                border: 1px solid #3E3E5E;
                selection-background-color: #00FFCC;
                selection-color: #000000;
            }
        """)
        self.device_list.currentIndexChanged.connect(self.check_if_device_rooted)
        section_layout.addWidget(self.device_list)

        # Add root status label
        self.root_status_label = QtWidgets.QLabel("Root status: Unknown")
        self.root_status_label.setStyleSheet("font: bold 12px 'Consolas'; color: #FFA500;")  # Default orange
        section_layout.addWidget(self.root_status_label, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        # Scrollable area for buttons
        scroll_area = QtWidgets.QScrollArea()
        scroll_area.setWidgetResizable(True)

        # Container widget for the buttons
        button_container = QtWidgets.QWidget()
        button_container.setStyleSheet("background-color: transparent;")  # Transparent background
        button_layout = QtWidgets.QVBoxLayout(button_container)
        button_layout.setContentsMargins(10, 10, 10, 10)
        button_layout.setSpacing(5)

        # Dynamically create buttons for menu items
        self.create_dynamic_buttons(button_layout)

        # Add button container to the scroll area
        scroll_area.setWidget(button_container)
        section_layout.addWidget(scroll_area)

        return section



    def check_if_device_rooted(self):
        """Check if the selected device is rooted."""
        selected_device = self.device_list.currentText()
        if not selected_device or selected_device == "No devices found":
            self.root_status_label.setText("Root status: Unknown")
            self.root_status_label.setStyleSheet("font: bold 12px 'Consolas'; color: #FFA500;")  # Orange for unknown
            return

        device_id = selected_device.split(" - ")[0]  # Extract device ID
        try:
            result = subprocess.run(
                ["adb", "-s", device_id, "shell", "su", "-c", "whoami"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            if "root" in result.stdout.strip():
                self.root_status_label.setText("Root status: Rooted")
                self.root_status_label.setStyleSheet("font: bold 12px 'Consolas'; color: #00FF00;")  # Green for rooted
            else:
                self.root_status_label.setText("Root status: Not Rooted")
                self.root_status_label.setStyleSheet("font: bold 12px 'Consolas'; color: #FF0000;")  # Red for not rooted
        except Exception as e:
            self.root_status_label.setText(f"Root status: Error ({str(e)})")
            self.root_status_label.setStyleSheet("font: bold 12px 'Consolas'; color: #FFA500;")  # Orange for error

    def populate_device_list(self):
        """Populate the QComboBox with connected ADB devices."""
        try:
            result = subprocess.run(["adb", "devices", "-l"], stdout=subprocess.PIPE, text=True)
            lines = result.stdout.strip().split("\n")[1:]  # Skip the header
            
            # Ensure the widget exists before accessing
            if self.device_list is None or self.adb_status_label is None:
                return
            
            self.device_list.clear()

            devices = []
            for line in lines:
                if line.strip():
                    device_id = line.split()[0]
                    model_match = re.search(r"model:(\S+)", line)
                    model = model_match.group(1) if model_match else "Unknown Model"
                    devices.append(f"{device_id} - {model}")

            if devices:
                self.device_list.addItems(devices)
                self.adb_status_label.setText("ADB Device(s) Detected.")
                self.adb_indicator_label.setStyleSheet("background-color: green; border-radius: 10px;")
            else:
                self.device_list.addItem("No devices found")
                self.adb_status_label.setText("No ADB Device Detected.")
                self.adb_indicator_label.setStyleSheet("background-color: red; border-radius: 10px;")

        except Exception as e:
            # Ensure the label exists before updating
            if self.adb_status_label:
                self.adb_status_label.setText(f"Error: {str(e)}")
            self.append_output(f"[ERROR] Failed to populate device list: {str(e)}\n", "red", "bold")


    def create_section1(self):
        """Create section 1 to display script output."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)

        # Output label
        output_label = QtWidgets.QLabel("Output:....")
        output_label.setStyleSheet("font: bold 14px 'Consolas'; color: #00FFCC;")
        section_layout.addWidget(output_label)

        # Output text area
        self.output_text_edit = TouchScrollableTextEdit()
        self.output_text_edit.setReadOnly(True)
        self.output_text_edit.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                color: #FFFFFF;
                font: 12px 'Consolas';
                border: 1px solid #3E3E5E;
                padding: 5px;
                border-radius: 5px;
            }
        """)
        section_layout.addWidget(self.output_text_edit, stretch=1)

        return section

    def start_adb_check_timer(self):
        """Start a timer to periodically check ADB devices."""
        self.adb_timer = QtCore.QTimer(self)
        self.adb_timer.timeout.connect(self.populate_device_list)
        self.adb_timer.start(3000)  # Check every 3 seconds








    def append_output(self, message, color="white", weight="normal"):
        """Append formatted and clean output to Section 1."""
        # Split the message into lines and format each line
        self.output_text_edit.clear()
        formatted_message = ""
        for line in message.strip().splitlines():
            formatted_message += f'<span style="color:{color}; font-weight:{weight};">{line}</span><br>'
        
        self.output_text_edit.append(formatted_message)
        self.output_text_edit.verticalScrollBar().setValue(
            self.output_text_edit.verticalScrollBar().maximum())








    def icon_path(self, name):
        """Resolve the icon path."""
        return os.path.join(os.path.dirname(__file__), "icon", name)

    def create_dynamic_buttons(self, layout):
        """Create buttons for ADB menu items dynamically."""
        adb_functions = {
            "1. Reboot Device": "adb -s {device_id} reboot",
            "2. Reboot to Bootloader": "adb -s {device_id} reboot-bootloader",
            "3. Reboot to Recovery": "adb -s {device_id} reboot recovery",
            "4. Monitor Running Processes": "adb -s {device_id} shell ps",
            "5. Check Battery Status": "adb -s {device_id} shell dumpsys battery",
            "6. Inspect Memory Usage": "adb -s {device_id} shell dumpsys meminfo",
            "7. Inspect CPU Usage": "adb -s {device_id} shell dumpsys cpuinfo",
        }


        for action, command_template in adb_functions.items():
            button = FuturisticPushButton(action)
            button.setStyleSheet("""
                QPushButton {
                    background-color: #3E3E5E;
                    border: 1px solid #00FFCC;
                    color: #FFFFFF;
                    font: bold 12px 'Consolas';
                    padding: 8px;
                    border-radius: 5px;
                }
                QPushButton:hover {
                    background-color: #1E1E2E;
                }
            """)
            button.clicked.connect(lambda _, cmd=command_template: self.run_adb_command(cmd))
            layout.addWidget(button, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)



    @pyqtSlot()
    def run_adb_command(self, command_template):
        """Run the ADB command for the selected device in a root shell using ADBWorker."""
        selected_device = self.device_list.currentText()
        if not selected_device or selected_device == "No devices found":
            self.append_output("[ERROR] No device selected.\n", "red", "bold")
            return

        device_id = selected_device.split(" - ")[0]  # Extract device ID
        command = command_template.format(device_id=device_id)

        try:
            # Attempt to restart ADB as root
            root_restart = subprocess.run(
                ["adb", "-s", device_id, "root"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            if "adbd is already running as root" in root_restart.stdout:
                self.append_output("[INFO] ADB is already running as root.\n", "blue", "bold")
            elif "restarting adbd as root" in root_restart.stdout:
                self.append_output("[INFO] Restarting ADB as root...\n", "blue", "bold")
            else:
                self.append_output("[WARNING] ADB root not supported on this device. Using 'su' instead.\n", "orange", "bold")

            # Check if root access is available
            root_check = subprocess.run(
                ["adb", "-s", device_id, "shell", "su", "-c", "id"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            is_root = "uid=0" in root_check.stdout

            # Adjust command if root is available
            if is_root:
                command = command.replace("adb -s {device_id} shell", f"adb -s {device_id} shell su -c")
                self.append_output("[INFO] Running command with root privileges.\n", "blue", "bold")
            else:
                # If root is required but not available
                if "su -c" in command_template or "root" in command_template:
                    self.append_output("[ERROR] Root permission needed. Can't run method.\n", "red", "bold")
                    return

            # Run the command in the worker thread
            self.worker = ADBWorker(command)
            self.worker.output_signal.connect(self.append_output)  # Connect worker output to append_output
            self.worker.start()

        except Exception as e:
            self.append_output(f"[ERROR] Failed to prepare command: {str(e)}\n", "red", "bold")








import os
import glob







class CommandWorkerL(QThread):
    result_signal = pyqtSignal(str)  # Signal to send command results back to the UI
    error_signal = pyqtSignal(str)   # Signal for errors

    def __init__(self, port, baud_rate, command, parent=None):
        super().__init__(parent)
        self.port = port
        self.baud_rate = baud_rate
        self.command = command

    def run(self):
        """Run the command in a background thread."""
        try:
            print(f"Opening serial connection on port {self.port} with baud rate {self.baud_rate}")  # Debug
            with serial.Serial(self.port, self.baud_rate, timeout=1) as ser:
                # Send the command
                self.send_command(ser, self.command)
                
                # Receive the full JSON response in chunks
                raw_response = self.receive_chunked_response(ser)
                
                # Attempt to parse the JSON data
                json_data=self.reconstruct_json(raw_response)
                self.result_signal.emit(json.dumps(json_data, indent=2))

                # Emit the reconstructed JSON as a string
        except Exception as e:
            self.error_signal.emit(f"Error: {e}")
            print(f"Error in CommandWorkerL: {e}")  # Debug log

    def send_command(self, ser, command):
        """Send a command to the linux host."""
        try:
            ser.write((command + "\n").encode())  # Send the command
            print(f"Sent command: {command}")  # Debug log
        except Exception as e:
            raise Exception(f"Error sending command: {e}")

    def receive_chunked_response(self, ser):
        """Receive large responses sent in chunks with an end marker."""
        response = ""
        try:
            while True:
                chunk = ser.readline().decode().strip()  # Read a chunk
                if not chunk:  # Handle empty buffer gracefully
                    continue
                print(f"Received chunk: {chunk[:50]}...")  # Debug log
                if chunk == "<END>":  # Stop reading when `<END>` marker is received
                    print("Received <END> marker.")
                    break
                response += chunk
            return response
        except Exception as e:
            raise Exception(f"Error receiving data: {e}")

    def reconstruct_json(self, raw_response):
        """Reconstruct the JSON data from the raw response."""
        try:
            # Attempt to parse the JSON string
            json_data = json.loads(raw_response)
            return json_data
        except json.JSONDecodeError as e:
            raise Exception(f"Error decoding JSON: {e}")





from PyQt6.QtCore import QThread, pyqtSignal
import serial
import time




class CommandWorker(QThread):
    result_signal = pyqtSignal(str)  # Signal to send command results back to the UI
    error_signal = pyqtSignal(str)   # Signal for errors

    def __init__(self, port, baud_rate, command, parent=None):
        super().__init__(parent)
        self.port = port
        self.baud_rate = baud_rate
        self.command = command

    def run(self):
        """Run the command in a background thread."""
        try:
            with serial.Serial(self.port, self.baud_rate, timeout=1) as ser:
                # Send the command
                self.send_command(ser, self.command)
                
                # Receive the full JSON response in chunks
                raw_response = self.receive_chunked_response(ser)
                
                # Attempt to parse the JSON data
                json_data = self.reconstruct_json(raw_response)
                
                # Emit the reconstructed JSON as a string
                self.result_signal.emit(json.dumps(json_data, indent=2))
        except Exception as e:
            self.error_signal.emit(f"Error: {e}")

    def send_command(self, ser, command):
        """Send a command to the Windows host."""
        try:
            ser.write((command + "\n").encode())  # Send the command
            print(f"Sent command: {command}")  # Debug log
        except Exception as e:
            raise Exception(f"Error sending command: {e}")

    def receive_chunked_response(self, ser):
        """Receive large responses sent in chunks with an end marker."""
        response = ""
        try:
            while True:
                chunk = ser.readline().decode().strip()  # Read a chunk
                if not chunk:  # Handle empty buffer gracefully
                    continue
                print(f"Received chunk: {chunk[:50]}...")  # Debug log
                if chunk == "<END>":  # Stop reading when `<END>` marker is received
                    print("Received <END> marker.")
                    break
                response += chunk
            return response
        except Exception as e:
            raise Exception(f"Error receiving data: {e}")

    def reconstruct_json(self, raw_response):
        """Reconstruct the JSON data from the raw response."""
        try:
            # Attempt to parse the JSON string
            json_data = json.loads(raw_response)
            return json_data
        except json.JSONDecodeError as e:
            raise Exception(f"Error decoding JSON: {e}")



class SerialMonitor(QThread):
    status_signal = pyqtSignal(str)  # Signal to emit connection status

    def __init__(self, port, baud_rate):
        super().__init__()
        self.port = port
        self.baud_rate = baud_rate
        self.running = True

    def run(self):
        while self.running:
            try:
                with serial.Serial(self.port, self.baud_rate, timeout=1) as ser:
                    ser.write(b"ping\n")  # Send ping
                    print("Sent: ping")  # Debug print
                    time.sleep(1)  # Wait for response

                    if ser.in_waiting > 0:
                        response = ser.readline().decode().strip()
                        print(f"Received: {response}")  # Debug print

                        # Check the response and emit appropriate signal
                        if response == "pong":
                            print("Emitting: Windows Connected")  # Debug print
                            self.status_signal.emit("Windows Connected")
                        elif response == "lpong":
                            print("Emitting: Linux Connected")  # Debug print
                            self.status_signal.emit("Linux Connected")
                        else:
                            print("Emitting: Disconnected (Invalid response)")  # Debug print
                            self.status_signal.emit("Disconnected")
                    else:
                        print("Emitting: Disconnected (No response)")  # Debug print
                        self.status_signal.emit("Disconnected")
            except Exception as e:
                # Handle exceptions and emit disconnected status
                print(f"Unexpected error: {e}")
                print("Emitting: Disconnected (Exception)")  # Debug print
                self.status_signal.emit("Disconnected")
            time.sleep(5)  # Retry every 5 seconds

    def stop(self):
        """Stop the thread gracefully."""
        self.running = False
        self.wait()  # Wait for the thread to finish execution before returning







class COMWidget(QtWidgets.QWidget):
    """Widget for monitoring COM port connections."""
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)

        # Add the XPloiter label at the top
        xploiter_label = QtWidgets.QLabel("XPloiter")
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setBold(True)
        xploiter_label.setFont(font)
        xploiter_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
        xploiter_label.setStyleSheet("color: #00FFCC; font: bold 16px 'Consolas';")
        layout.addWidget(xploiter_label)

        self.SERIAL_PORT = "/dev/serial0"  # Adjust this port to match your system
        self.BAUD_RATE = 9600

        # Add the sections
        sections_layout = QtWidgets.QHBoxLayout()
        sections_layout.setContentsMargins(0, 0, 0, 0)

        section0 = self.create_section0()
        section1 = self.create_section1()

            # Add sections to the main layout
        sections_layout.addWidget(section0, stretch=1)

            # Vertical divider
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.VLine)
        line.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        sections_layout.addWidget(line)

        sections_layout.addWidget(section1, stretch=1)
        layout.addLayout(sections_layout)
        self.start_connection_monitor()

    def icon_path(self, name):
        """Resolve the icon path."""
        return os.path.join(os.path.dirname(__file__), "icon", name)

    def create_section0(self):
        """Create Ethernet status display section with overlay."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)

        # Upper half for Ethernet status
        upper_half = QtWidgets.QWidget()
        upper_half_layout = QtWidgets.QVBoxLayout(upper_half)
        self.win_con_label = QtWidgets.QLabel("Serial server checking (Windows)...")
        self.win_con_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.win_con_label.setStyleSheet("color: #00FFCC; font: bold 12px 'Consolas';")
        upper_half_layout.addWidget(self.win_con_label)

        # QLabelWithOverlay instance
        self.windows_live = QLabelWithOverlay(self.icon_path("windows.png"))
        self.windows_live.setFixedSize(200, 200)
        upper_half_layout.addWidget(self.windows_live, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)
        section_layout.addWidget(upper_half, stretch=1)
        
        lower_half=QtWidgets.QWidget()
        lower_half_layout = QtWidgets.QVBoxLayout(lower_half)
        self.windows_con = TouchScrollableTextEdit()
        self.windows_con.setReadOnly(True)
        self.windows_con.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: 12px 'Consolas';
            }
        """)
        lower_half_layout.addWidget(self.windows_con)
        self.proceed_button = FuturisticPushButton("Proceed towards windows live analysis")
        self.proceed_button.setStyleSheet("""
        QPushButton {
        background-color: #00FFCC;
        color: #1A1A2A;
        font: bold 14px 'Consolas';
        border-radius: 5px;
        }
        QPushButton:hover {
        background-color: #1A1A2A;
        color: #00FFCC;
        border: 2px solid #00FFCC;
        }
        """)
        self.proceed_button.clicked.connect(self.on_proceed_clicked)
        self.proceed_button.setVisible(False)
        lower_half_layout.addWidget(self.proceed_button, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)
        section_layout.addWidget(lower_half, stretch=1)

        # Start monitoring the serial connection
        return section

    def start_connection_monitor(self):
        """Start monitoring the serial connection."""
        print("Starting serial connection monitor...")  # Debug print
        self.serial_monitor = SerialMonitor(self.SERIAL_PORT, self.BAUD_RATE)
        self.serial_monitor.status_signal.connect(self.handle_serial_status)
        self.serial_monitor.start()
        print("Serial monitor started.")  # Debug print


    def handle_serial_status(self, status: str):
        """Update the UI based on the serial connection status."""
        print(f"Serial status: {status}")  # Debug print

        if status == "Windows Connected":
            self.windows_live.set_overlay("tick")  # Indicate successful connection
            self.proceed_button.setVisible(True)  # Enable proceed button
            self.windows_con.setVisible(False)  # Hide connection message
        elif status == "Linux Connected":
            self.linux_live.set_overlay("tick")  # Indicate successful connection
            self.proceed_buttonl.setVisible(True)  # Enable proceed button
            self.linux_con.setVisible(False)  # Hide connection message
        elif status == "Disconnected":
            self.windows_live.set_overlay("circle")  # Indicate disconnection
            self.proceed_button.setVisible(False)  # Disable proceed button
            self.windows_con.setVisible(True)  # Show connection message
            self.windows_con.append("No response from the host.")  # Update message


            self.linux_live.set_overlay("circle")  # Indicate disconnection
            self.proceed_buttonl.setVisible(False)  # Disable proceed button
            self.linux_con.setVisible(True)  # Show connection message
            self.linux_con.append("No response from the host.")  # Update message










    def clear_layout(self, layout):
        """Recursively clear all items in a layout."""
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()  # Delete widgets like labels, buttons, etc.
            elif item.layout():
                self.clear_layout(item.layout())  # Recursively clear nested layouts

    def on_proceed_clicked(self):
        """Handle proceed button click and load the command interface."""
        # Stop the serial monitor if running
        self.serial_monitor.stop()
        self.serial_monitorl.stop()

        # Clear the existing layout or content
        while self.layout().count():
            item = self.layout().takeAt(0)  # Get the first item
            widget = item.widget()
            if widget:
                widget.deleteLater()  # Remove widgets like labels, buttons, etc.
            elif item.layout():
                self.clear_layout(item.layout())

        # Create a new widget and layout
        new_widget = QtWidgets.QWidget()
        main_layout = QtWidgets.QHBoxLayout(new_widget)  # Horizontal layout for two sections

        # Left section with image and buttons
        left_widget = QtWidgets.QWidget()
        left_layout = QtWidgets.QVBoxLayout(left_widget)
        left_layout.setContentsMargins(10, 10, 10, 10)

        # Add the windows.png image at the top left
        image_label = QtWidgets.QLabel()
        pixmap = QtGui.QPixmap(self.icon_path("windows.png"))
        image_label.setPixmap(pixmap)
        image_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignTop)
        left_layout.addWidget(image_label)
        
        host_label = QtWidgets.QLabel()
        host_label.setText("Windows Live")
        image_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignTop)
        left_layout.addWidget(host_label)

        # Define commands and their corresponding actions
        commands = [
            ("Get System Info", "get_system_info"),
            ("Get Running Processes", "get_running_processes"),
            ("Detailed Network analysis", "get_detailed_network_connections"),
            ("Detailed Disk Analysis", "detailed_disk_analysis"),
            ("Deep Registry Analysis", "deep_registry_analysis"),
        ]

        # Add buttons for each command
        for label, command in commands:
            button = FuturisticPushButton(label)
            button.setStyleSheet("""
                QPushButton {
                    background-color: #00FFCC;
                    color: #1A1A2A;
                    font: bold 12px 'Consolas';
                    border-radius: 5px;
                    padding: 5px;
                    margin: 5px 0;
                }
                QPushButton:hover {
                    background-color: #1A1A2A;
                    color: #00FFCC;
                    border: 2px solid #00FFCC;
                }
            """)
            button.setSizePolicy(QtWidgets.QSizePolicy.Policy.Fixed, QtWidgets.QSizePolicy.Policy.Fixed)
            button.setFixedWidth(200)  # Optional: Fixed width for better alignment
            button.clicked.connect(lambda _, cmd=command: self.run_command_in_thread(cmd))
            left_layout.addWidget(button, alignment=QtCore.Qt.AlignmentFlag.AlignLeft)

        main_layout.addWidget(left_widget)

        # Add a vertical line
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.VLine)
        line.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        line.setLineWidth(1)
        line.setContentsMargins(0, 0, 0, 0)  # Add some spacing to the left and right
        main_layout.addWidget(line)

        # Right section for command responses
        self.response_widget = TouchScrollableTextEdit()  # Use QTextEdit for displaying responses
        self.response_widget.setReadOnly(True)
        self.response_widget.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.response_widget.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.response_widget.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                color: #FFFFFF;
                font: 12px 'Consolas';
                border: 1px solid #3E3E5E;
            }
        """)
        main_layout.addWidget(self.response_widget)

        # Add the new widget to the main layout
        self.layout().addWidget(new_widget)







    def run_command_in_thread(self, command):
        """Run the specified command in a background thread."""
        # Create a new instance of CommandWorker for the selected command
        self.command_worker = CommandWorker(self.SERIAL_PORT, self.BAUD_RATE, command)
        
        # Connect signals to handle results or errors
        self.command_worker.result_signal.connect(self.handle_command_result)
        self.command_worker.error_signal.connect(self.handle_command_error)
        
        # Start the thread
        self.command_worker.start()



    def handle_command_result(self, result):
        """Handle the result emitted by the CommandWorker."""
        print(f"Command result: {result}")
        self.response_widget.clear()
        if hasattr(self, 'response_widget'):
            # Append the result to the QTextEdit
            self.response_widget.append(result)

    def handle_command_error(self, error):
        """Handle errors emitted by the CommandWorker."""
        print(f"Command error: {error}")
        # Show the error in a message box or log it to the UI
        QtWidgets.QMessageBox.critical(self, "Command Error", error)

    def create_section1(self):
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(0, 0, 0, 0)

        # Upper half for Ethernet status
        upper_half = QtWidgets.QWidget()
        upper_half_layout = QtWidgets.QVBoxLayout(upper_half)
        self.linux_con_label = QtWidgets.QLabel("Serial server checking (Any Linux)...")
        self.linux_con_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.linux_con_label.setStyleSheet("color: #00FFCC; font: bold 12px 'Consolas';")
        upper_half_layout.addWidget(self.linux_con_label)

        # QLabelWithOverlay instance
        self.linux_live = QLabelWithOverlay(self.icon_path("linux.png"))
        self.linux_live.setFixedSize(200, 200)
        upper_half_layout.addWidget(self.linux_live, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)
        section_layout.addWidget(upper_half, stretch=1)
        
        lower_half=QtWidgets.QWidget()
        lower_half_layout = QtWidgets.QVBoxLayout(lower_half)
        self.linux_con = TouchScrollableTextEdit()
        self.linux_con.setReadOnly(True)
        self.linux_con.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: 12px 'Consolas';
            }
        """)
        lower_half_layout.addWidget(self.linux_con)
        self.proceed_buttonl = FuturisticPushButton("Proceed towards linux live analysis")
        self.proceed_buttonl.setStyleSheet("""
        QPushButton {
        background-color: #00FFCC;
        color: #1A1A2A;
        font: bold 14px 'Consolas';
        border-radius: 5px;
        }
        QPushButton:hover {
        background-color: #1A1A2A;
        color: #00FFCC;
        border: 2px solid #00FFCC;
        }
        """)
        self.proceed_buttonl.clicked.connect(self.on_proceed_clickedL)
        self.proceed_buttonl.setVisible(False)
        lower_half_layout.addWidget(self.proceed_buttonl)
        section_layout.addWidget(lower_half, stretch=2)
        # Start monitoring the serial connection
        return section












    def on_proceed_clickedL(self):
        """Handle proceed button click and load the command interface."""
        # Stop the serial monitor if running
        self.serial_monitorl.stop()
        self.serial_monitor.stop()

        # Clear the existing layout or content
        while self.layout().count():
            item = self.layout().takeAt(0)  # Get the first item
            widget = item.widget()
            if widget:
                widget.deleteLater()  # Remove widgets like labels, buttons, etc.
            elif item.layout():
                self.clear_layout(item.layout())

        # Create a new widget and layout
        new_widget = QtWidgets.QWidget()
        main_layout = QtWidgets.QHBoxLayout(new_widget)  # Horizontal layout for two sections

        # Left section with image and buttons
        left_widget = QtWidgets.QWidget()
        left_layout = QtWidgets.QVBoxLayout(left_widget)
        left_layout.setContentsMargins(10, 10, 10, 10)

        # Add the linux.png image at the top left
        image_label = QtWidgets.QLabel()
        pixmap = QtGui.QPixmap(self.icon_path("linux.png"))
        image_label.setPixmap(pixmap)
        image_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignTop)
        left_layout.addWidget(image_label)
        
        host_label = QtWidgets.QLabel()
        host_label.setText("Linux Live")
        image_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignTop)
        left_layout.addWidget(host_label)

        # Define commands and their corresponding actions
        commands = [
            ("System_Info", "get_system_info"),
            ("Running_Processes", "get_running_processes"),
            ("Memory_Info", "get_memory_info"),
            ("Network_Activity", "get_network_activity"),
            ("Filesystem_Info", "get_filesystem_info"),
            ("User_Activity", "get_logs_and_user_activity"),
            ("User_and_Privilege_Info", "get_user_and_privilege_info"),
            ("Scheduled_Tasks", "get_scheduled_tasks"),
            ("Malware_and_Rootkit_Scan", "get_malware_and_rootkit_scan"),
        ]


        # Add buttons for each command
        for label, command in commands:
            button = FuturisticPushButton(label)
            button.setStyleSheet("""
                QPushButton {
                    background-color: #00FFCC;
                    color: #1A1A2A;
                    font: bold 12px 'Consolas';
                    border-radius: 5px;
                    padding: 5px;
                    margin: 5px 0;
                }
                QPushButton:hover {
                    background-color: #1A1A2A;
                    color: #00FFCC;
                    border: 2px solid #00FFCC;
                }
            """)
            button.setSizePolicy(QtWidgets.QSizePolicy.Policy.Fixed, QtWidgets.QSizePolicy.Policy.Fixed)
            button.setFixedWidth(200)  # Optional: Fixed width for better alignment
            button.clicked.connect(lambda _, cmd=command: self.run_command_in_threadL(cmd))
            left_layout.addWidget(button, alignment=QtCore.Qt.AlignmentFlag.AlignLeft)

        main_layout.addWidget(left_widget)

        # Add a vertical line
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.VLine)
        line.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        line.setLineWidth(1)
        line.setContentsMargins(5, 0, 5, 0)  # Add some spacing to the left and right
        main_layout.addWidget(line)

        # Right section for command responses
        self.response_widgetl = TouchScrollableTextEdit()  # Use QTextEdit for displaying responses
        self.response_widgetl.setReadOnly(True)
        self.response_widgetl.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.response_widgetl.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.response_widgetl.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                color: #FFFFFF;
                font: 12px 'Consolas';
                border: 1px solid #3E3E5E;
            }
        """)
        main_layout.addWidget(self.response_widgetl)

        # Add the new widget to the main layout
        self.layout().addWidget(new_widget)







    def run_command_in_threadL(self, command):
        """Run the specified command in a background thread."""
        # Create a new instance of CommandWorker for the selected command
        self.command_workerl = CommandWorkerL(self.SERIAL_PORT, self.BAUD_RATE, command)
        
        # Connect signals to handle results or errors
        self.command_workerl.result_signal.connect(self.handle_command_resultL)
        self.command_workerl.error_signal.connect(self.handle_command_errorL)
        
        # Start the thread
        self.command_workerl.start()



    def handle_command_resultL(self, result):
        """Handle the result emitted by the CommandWorker."""
        print(f"Command result: {result}")
        self.response_widgetl.clear()
        if hasattr(self, 'response_widgetl'):
            # Append the result to the QTextEdit
            self.response_widgetl.append(result)

    def handle_command_errorL(self, error):
        """Handle errors emitted by the CommandWorker."""
        print(f"Command error: {error}")
        # Show the error in a message box or log it to the UI
        QtWidgets.QMessageBox.critical(self, "Command Error", error)





















from PyQt6.QtCore import QThread, pyqtSignal

class RFIDWorker(QThread):
    progress = pyqtSignal(str)
    finished = pyqtSignal()
    request_input = pyqtSignal()

    def __init__(self, operation, parent=None):
        super().__init__(parent)
        self.operation = operation
        self.user_input = None
        self.running = True

    def wait_for_input(self):
        while self.user_input is None and self.running:
            self.msleep(100)

    def run(self):
        try:
            if self.operation == "dump_info":
                self.dump_info()
            elif self.operation == "write":
                self.write_data()
            elif self.operation == "read_uid":
                self.read_uid()
            else:
                self.progress.emit("Unknown operation.")
        except Exception as e:
            self.progress.emit(f"Error: {e}")
        finally:
            self.finished.emit()

    def dump_info(self):
        self.progress.emit("Place your tag near the reader to dump data...")
        reader = SimpleMFRC522()
        try:
            id, text = reader.read()
            self.progress.emit(f"Card ID: {id}")
            self.progress.emit(f"Card Data: {text}")
        except Exception as e:
            self.progress.emit(f"Error during dump info: {e}")

    def write_data(self):
        self.progress.emit("Waiting for user input to write data...")
        self.request_input.emit()
        self.wait_for_input()

        if self.user_input:
            reader = SimpleMFRC522()
            try:
                self.progress.emit("Place your tag near the reader to write data...")
                reader.write(self.user_input)
                self.progress.emit("Data written successfully!")

                id, text = reader.read()
                self.progress.emit(f"Verified ID: {id}")
                self.progress.emit(f"Verified Data: {text}")
            except Exception as e:
                self.progress.emit(f"Error during write operation: {e}")
        else:
            self.progress.emit("No data provided. Write operation aborted.")

    def read_uid(self):
        reader = SimpleMFRC522()
        try:
            id, _ = reader.read()
            if id:
                self.progress.emit(f"Card UID: {id}")
            else:
                self.progress.emit("No UID detected.")
        except Exception as e:
            self.progress.emit(f"Error reading UID: {e}")

    def stop(self):
        self.running = False





class RFIDImagerWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
        self.reader = SimpleMFRC522()  # Initialize the RFID reader
        self.worker = None  # Placeholder for the worker thread

    def setup_ui(self):
        # Main layout
        self.main_layout = QtWidgets.QVBoxLayout(self)
        self.main_layout.setContentsMargins(10, 10, 10, 10)
        self.main_layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)

        # Add the XPloiter label at the top
        xploiter_label = QtWidgets.QLabel("XPloiter")
        font = QFont()
        font.setPointSize(16)
        font.setBold(True)
        xploiter_label.setFont(font)
        xploiter_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
        xploiter_label.setStyleSheet("color: #00FFCC; font: bold 16px 'Consolas'; background: transparent;")
        self.main_layout.addWidget(xploiter_label)

        # Horizontal layout for sections
        self.sections_layout = QtWidgets.QHBoxLayout()
        self.sections_layout.setContentsMargins(0, 0, 0, 0)

        # Add two sections divided by a vertical line
        section0 = self.create_section0()  # Drive info and actions
        section1 = self.create_section1()  # Imaging output and progress
        self.sections_layout.addWidget(section0, stretch=1)

        # Vertical divider
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.VLine)
        line.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        line.setStyleSheet("background: transparent; border: 1px solid #3E3E5E;")
        self.sections_layout.addWidget(line)

        self.sections_layout.addWidget(section1, stretch=1)
        self.main_layout.addLayout(self.sections_layout)

    def create_section0(self):
        """Create section to display the RFID menu, detailed drive info, and action buttons."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)

        # Add RFID image at the top
        rfid_label = QtWidgets.QLabel()
        rfid_pixmap = QtGui.QPixmap(self.icon_path("rfid_chip.png")).scaled(
            100, 100, QtCore.Qt.AspectRatioMode.KeepAspectRatio
        )
        rfid_label.setPixmap(rfid_pixmap)
        rfid_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        section_layout.addWidget(rfid_label)

        # Add RFID operations list
        self.menu_list = QtWidgets.QListWidget()
        self.menu_list.setStyleSheet("""
            QListWidget {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
                border-radius: 5px;
            }
            QListWidget::item {
                padding: 10px;
            }
            QListWidget::item:selected {
                background-color: #3E3E5E;
                color: #00FFCC;
            }
        """)
        self.menu_list.addItems([
            "Dump Info",
            "Write",
            "Authenticate",
            "Read UID"
        ])
        self.menu_list.itemClicked.connect(self.handle_menu_click)
        section_layout.addWidget(self.menu_list)

        return section

    def handle_menu_click(self, item):
        """Handle RFID menu item click."""
        operation_map = {
            "Dump Info": "dump_info",
            "Write": "write",
            "Read UID": "read_uid",
        }
        operation = operation_map.get(item.text())
        if operation:
            self.start_worker(operation)
        else:
            self.update_output("Invalid menu item selected.")


    def start_worker(self, operation):
        if self.worker and self.worker.isRunning():
            self.output_text.append("Another operation is already running. Please wait.")
            return

        self.worker = RFIDWorker(operation, mfrc_reader=MFRC522(), simple_reader=self.reader)
        self.worker.progress.connect(self.update_output)
        self.worker.finished.connect(self.worker_finished)
        if operation == "write":
            self.worker.request_input.connect(self.get_user_input)
        self.worker.start()



    def get_user_input(self):
        """Show an input dialog and send the result to the worker."""
        data, ok = QtWidgets.QInputDialog.getText(self, "Write Data", "Enter data to write on the tag:")
        if ok and data:
            self.worker.user_input = data
        else:
            self.worker.user_input = None

    def update_output(self, message):
        if "[INFO]" in message:
            color = "#00FF00"
        elif "[WARNING]" in message:
            color = "#FFFF00"
        elif "[ERROR]" in message:
            color = "#FF0000"
        else:
            color = "#FFFFFF"

        self.output_text.append(f'<span style="color:{color};">{message}</span>')
        self.output_text.verticalScrollBar().setValue(self.output_text.verticalScrollBar().maximum())

    def stop_worker(self):
        """Stop the RFID worker thread if running."""
        if self.worker and self.worker.isRunning():
            self.worker.running = False
            self.worker.wait()
            self.worker = None
            self.output_text.append("Operation canceled.")



    def worker_finished(self):
        """Handle worker finished signal."""
        self.output_text.append("Operation completed.")
        self.worker = None  # Reset worker instance


    def create_section1(self):
        """Create section to display output of the imaging process and add warning indicators."""
        section = QtWidgets.QWidget()
        self.section_layout = QtWidgets.QVBoxLayout(section)
        self.section_layout.setContentsMargins(10, 10, 10, 10)

        # Output text area
        self.output_text = TouchScrollableTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: 12px 'Consolas';
                border-radius: 5px;
            }
        """)
        self.section_layout.addWidget(self.output_text)

        return section

    def icon_path(self, name):
        """Resolve the icon path."""
        return os.path.join(os.path.dirname(__file__), "icon", name)




























class LogReaderThread(QThread):
    log_line = pyqtSignal(str)  # Signal to emit each line of output

    def __init__(self, command):
        super().__init__()
        self.command = command

    def run(self):
        """Run the command and emit output line by line."""
        try:
            process = subprocess.Popen(
                self.command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True
            )

            for line in process.stdout:
                self.log_line.emit(line.strip())

            process.wait()
        except Exception as e:
            self.log_line.emit(f"[ERROR] {str(e)}")








import os
import re
import subprocess
from PyQt6 import QtWidgets, QtGui, QtCore
from PyQt6.QtWidgets import QMessageBox, QTreeWidgetItem

# Note: Ensure that these helper classes and threads are defined/imported in your project:
# - LogReaderThread
# - QLabelWithOverlay
# - FuturisticPushButton
# - TouchScrollableTextEdit

class AndroidLogicalWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.results_folder="./results"
        self.setup_ui()
        self.start_adb_check_timer()  # Start the ADB check timer

    def setup_ui(self):
        # Main horizontal layout
        main_layout = QtWidgets.QHBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)

        # Create sections
        section0 = self.create_section0()
        section1 = self.create_section1()

        # Add sections to the main layout
        main_layout.addWidget(section0, stretch=1)

        # Vertical divider
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.VLine)
        line.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        main_layout.addWidget(line)

        main_layout.addWidget(section1, stretch=1)

    def image_device_logically(self):
        """Run a script to image the selected device logically."""
        selected_device = self.device_list.currentText()
        if not selected_device or selected_device == "No devices found":
            QMessageBox.warning(self, "No Device Selected", "Please select a valid device to image.")
            return

        # Primary storage is now always represented by the results folder.
        # Extract device ID from the selected text (assuming format: "device_id - model_name")
        device_id = selected_device.split(" - ")[0]

        # Prepare the command with the output directory (results folder) as an argument
        command = ["sudo", "bash", "./bin/logical.sh", device_id, self.results_folder]
        try:
            # Start the LogReaderThread to run the command
            self.log_reader_thread = LogReaderThread(command)
            self.log_reader_thread.log_line.connect(self.dynamic_append_output)  # Connect signal to output method
            self.log_reader_thread.finished.connect(self.show_analysis_button)  # Show button after thread finishes
            self.log_reader_thread.start()  # Start the thread

            # Inform the user that imaging has started
            QMessageBox.information(self, "Imaging Started",
                                    f"Logical imaging for device {device_id} started.\n")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to start logical imaging: {e}")

    def show_analysis_button(self):
        """Make the Analyze button visible after the extraction is complete."""
        self.analysis_button.setVisible(True)

    def find_logical_directory(self, base_dir, device_id):
        """Find a directory matching the given device ID in the base directory."""
        logical_dir = os.path.join(base_dir, device_id+"-logical")
        if os.path.exists(logical_dir) and os.path.isdir(logical_dir):
            return logical_dir
        return None  # Return None if no match is found

    def display_directory_tree(self, device_id):
        """Display both the directory tree and filetype-specific tree for a folder named after the device ID."""
        print(f"[DEBUG] Entered display_directory_tree with device_id: {device_id}")
        base_dir="./results"
        # Use the results folder instead of a mount point
        logical_dir = self.find_logical_directory(base_dir, device_id)

        if not logical_dir:
            QMessageBox.warning(self, "Directory Not Found", f"No directory found for device ID: {device_id}.")
            print(f"[DEBUG] Directory not found: {logical_dir}")
            return

        # Clear the existing layout safely
        self.clear_existing_layout()

        # Create a new layout for the trees
        layout = QtWidgets.QHBoxLayout()
        self.setLayout(layout)

        # Directory tree widget
        self.directory_tree = QtWidgets.QTreeWidget()
        self.directory_tree.setHeaderLabel("Directory Structure")
        self.apply_tree_styling(self.directory_tree)
        layout.addWidget(self.directory_tree)

        # Filetype tree widget
        self.filetype_tree = QtWidgets.QTreeWidget()
        self.filetype_tree.setHeaderLabel("File Types")
        self.apply_tree_styling(self.filetype_tree)
        layout.addWidget(self.filetype_tree)

        # Populate the directory and file type trees
        self.populate_directory_tree(logical_dir, self.directory_tree)
        self.populate_filetype_tree(logical_dir, self.filetype_tree)

    def populate_directory_tree(self, root_path, tree_widget):
        """Recursively populate the directory tree."""
        tree_widget.clear()
        tree_widget.setItemsExpandable(True)
        tree_widget.setRootIsDecorated(True)

        def add_items(parent, path):
            try:
                for item in sorted(os.listdir(path)):
                    full_path = os.path.join(path, item)
                    tree_item = QTreeWidgetItem([item])
                    parent.addChild(tree_item)
                    if os.path.isdir(full_path):
                        add_items(tree_item, full_path)
            except FileNotFoundError:
                print(f"[DEBUG] Directory not found: {path}")
                return

        root_item = QTreeWidgetItem([os.path.basename(root_path)])
        tree_widget.addTopLevelItem(root_item)
        add_items(root_item, root_path)
        tree_widget.expandAll()

    def populate_filetype_tree(self, root_path, tree_widget):
        """Organize files by type in the filetype tree."""
        tree_widget.clear()
        file_types = {
            "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp"],
            "Videos": [".mp4", ".mkv", ".avi", ".mov"],
            "Documents": [".pdf", ".docx", ".xlsx", ".txt"],
            "Audio": [".mp3", ".wav", ".aac"],
            "Archives": [".zip", ".rar", ".tar", ".gz"],
            "Others": []  # For unrecognized file types
        }

        # Create top-level items for each file type
        type_items = {key: QTreeWidgetItem([key]) for key in file_types}
        for item in type_items.values():
            tree_widget.addTopLevelItem(item)

        def categorize_files(path):
            for root, _, files in os.walk(path):
                for file in files:
                    file_path = os.path.join(root, file)
                    file_ext = os.path.splitext(file)[-1].lower()
                    added = False
                    for key, extensions in file_types.items():
                        if file_ext in extensions:
                            QTreeWidgetItem(type_items[key], [file])
                            added = True
                            break
                    if not added:
                        QTreeWidgetItem(type_items["Others"], [file])

        categorize_files(root_path)
        tree_widget.expandAll()

    def set_icons_recursively(self, item, open_icon, closed_icon):
        """Recursively set icons for tree branches."""
        item.setExpanded(True)  # Initially expanded for testing
        item.setIcon(0, closed_icon)
        for i in range(item.childCount()):
            self.set_icons_recursively(item.child(i), open_icon, closed_icon)

    def apply_tree_styling(self, tree_widget):
        """Apply modern futuristic styling to the tree widgets."""
        tree_widget.setStyleSheet(f"""
            QTreeWidget {{
                background-color: qlineargradient(
                    spread:pad, x1:0, y1:0, x2:1, y2:1, 
                    stop:0 #1A1A2A, stop:1 #2B2B3B
                );
                color: #E0E0E0;
                font: bold 14px 'Courier New';
                border: 2px solid #444;
                border-radius: 10px;
                padding: 8px;
            }}
            QTreeWidget::item {{
                color: #C0C0C0;
            }}
            QTreeWidget::item:hover {{
                background-color: #33334F;
                color: #FFFFFF;
                border: 1px solid #5E5EFF;
            }}
            QTreeWidget::item:selected {{
                background-color: #1E90FF;
                color: #FFFFFF;
                font-weight: bold;
            }}
        """)
        tree_widget.setIconSize(QtCore.QSize(20, 20))
        tree_widget.header().setStyleSheet("""
            QHeaderView::section {
                background-color: #2A2A3A;
                color: #00BFFF;
                font: bold 16px 'Courier New';
                padding: 6px;
                border: 1px solid #444;
            }
        """)

    def set_branch_icons(self, tree_widget):
        """Set branch icons dynamically."""
        open_icon = QtGui.QIcon("/home/pi/XPloiter/icon/exploit.png")
        closed_icon = QtGui.QIcon("/home/pi/XPloiter/icon/exploit.png")

        def apply_icons(item):
            for i in range(item.childCount()):
                child = item.child(i)
                if child.childCount() > 0:  # Only apply to branches
                    child.setIcon(0, closed_icon)
                    apply_icons(child)

        root = tree_widget.invisibleRootItem()
        for i in range(root.childCount()):
            root.child(i).setIcon(0, closed_icon)
            apply_icons(root.child(i))

        tree_widget.itemExpanded.connect(lambda item: item.setIcon(0, open_icon))
        tree_widget.itemCollapsed.connect(lambda item: item.setIcon(0, closed_icon))

    def clear_existing_layout(self):
        """Clear the current layout and reset to an empty layout."""
        layout = self.layout()
        if layout is not None:
            while layout.count():
                item = layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
                elif item.layout():
                    self.clear_layout_recursively(item.layout())
            QtWidgets.QWidget().setLayout(layout)

    def clear_layout_recursively(self, layout):
        """Recursively clear nested layouts."""
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
            elif item.layout():
                self.clear_layout_recursively(item.layout())

    def on_analyze_click(self):
        """Handle Analyze button click to display directory and file type trees."""
        if hasattr(self, "adb_timer"):
            self.adb_timer.stop()

        self.clear_existing_layout()
        layout = QtWidgets.QHBoxLayout(self)
        self.directory_tree = QtWidgets.QTreeWidget()
        self.directory_tree.setHeaderLabel("Directory Structure")
        self.apply_tree_styling(self.directory_tree)
        layout.addWidget(self.directory_tree)
        self.filetype_tree = QtWidgets.QTreeWidget()
        self.filetype_tree.setHeaderLabel("File Types")
        self.apply_tree_styling(self.filetype_tree)
        layout.addWidget(self.filetype_tree)
        self.setLayout(layout)

        device_id = self.device_list.currentText().split(" - ")[0].strip()
        if not device_id:
            QMessageBox.warning(self, "Invalid Device ID", "Please select a valid device.")
            print("[DEBUG] Invalid Device ID selected.")
            return

        print(f"[DEBUG] Device ID: {device_id}")
        self.display_directory_tree(device_id)

    def dynamic_append_output(self, line):
        """Append script output dynamically to Section 1."""
        formatted_line = f"{line}\n\n"
        if "[SUCCESS]" in line:
            self.append_output(formatted_line, "green", "bold")
        elif "[ERROR]" in line:
            self.append_output(formatted_line, "red", "bold")
        elif "[INFO]" in line:
            self.append_output(formatted_line, "blue", "bold")
        else:
            self.append_output(formatted_line, "white", "normal")

    def create_section0(self):
        """Create section 0 with Android image, ADB status, and device selection."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)
        section_layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)

        # Add Android image
        android_label = QtWidgets.QLabel()
        android_pixmap = QtGui.QPixmap(self.icon_path("android.png")).scaled(
            200, 200, QtCore.Qt.AspectRatioMode.KeepAspectRatio
        )
        android_label.setPixmap(android_pixmap)
        android_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        section_layout.addWidget(android_label, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        # Horizontal layout for ADB status and indicator
        status_layout = QtWidgets.QHBoxLayout()
        self.adb_status_label = QtWidgets.QLabel("Checking ADB connection...")
        self.adb_status_label.setStyleSheet("font: bold 14px 'Consolas'; color: #00FFCC;")
        status_layout.addWidget(self.adb_status_label)
        self.adb_indicator_label = QtWidgets.QLabel()
        self.adb_indicator_label.setFixedSize(20, 20)
        self.adb_indicator_label.setStyleSheet("background-color: red; border-radius: 10px;")
        status_layout.addWidget(self.adb_indicator_label)
        section_layout.addLayout(status_layout)

        # Device list dropdown
        self.device_list = QtWidgets.QComboBox()
        self.device_list.setStyleSheet("""
            QComboBox {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
                border-radius: 5px;
            }
            QComboBox QAbstractItemView {
                background-color: #000000;
                color: #FFFFFF;
                border: 1px solid #3E3E5E;
                selection-background-color: #00FFCC;
                selection-color: #000000;
            }
        """)
        section_layout.addWidget(self.device_list)

        # "Image Device Logically" button
        self.image_button = FuturisticPushButton("Image Device Logically")
        self.image_button.setStyleSheet("""
            QPushButton {
                background-color: #3E3E5E;
                border: 1px solid #00FFCC;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 8px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #1E1E2E;
            }
        """)
        self.image_button.clicked.connect(self.image_device_logically)
        section_layout.addWidget(self.image_button, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        # Analysis button placeholder
        self.analysis_button = FuturisticPushButton("Analyze Extracted Data")
        self.analysis_button.setStyleSheet("""
            QPushButton {
                background-color: #1E1E2E;
                border: 1px solid #00FFCC;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 8px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #3E3E5E;
            }
        """)
        self.analysis_button.setVisible(False)
        section_layout.addWidget(self.analysis_button, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)
        self.analysis_button.clicked.connect(self.on_analyze_click)

        return section

    def create_section1(self):
        """Create section 1 to display script output."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)

        # Output label
        output_label = QtWidgets.QLabel("Output:")
        output_label.setStyleSheet("font: bold 14px 'Consolas'; color: #00FFCC;")
        section_layout.addWidget(output_label)

        # Output text area
        self.output_text_edit = TouchScrollableTextEdit()
        self.output_text_edit.setReadOnly(True)
        self.output_text_edit.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                color: #FFFFFF;
                font: 12px 'Consolas';
                border: 1px solid #3E3E5E;
                padding: 5px;
                border-radius: 5px;
            }
        """)
        section_layout.addWidget(self.output_text_edit, stretch=1)

        # Directory tree view (initially hidden)
        self.directory_tree = QtWidgets.QTreeWidget()
        self.directory_tree.setHeaderLabel("Directory Structure")
        self.directory_tree.setStyleSheet("""
            QTreeWidget {
                background-color: #1A1A2A;
                color: #FFFFFF;
                font: 12px 'Consolas';
                border: 1px solid #3E3E5E;
                padding: 5px;
                border-radius: 5px;
            }
        """)
        self.directory_tree.setVisible(False)
        section_layout.addWidget(self.directory_tree, stretch=2)

        return section

    def start_adb_check_timer(self):
        """Start a timer to periodically check ADB devices."""
        self.adb_timer = QtCore.QTimer(self)
        self.adb_timer.timeout.connect(self.populate_device_list)
        self.adb_timer.start(3000)  # Check every 3 seconds

    def populate_device_list(self):
        """Populate the QComboBox with connected ADB devices."""
        try:
            result = subprocess.run(["adb", "devices", "-l"], stdout=subprocess.PIPE, text=True)
            lines = result.stdout.strip().split("\n")[1:]  # Skip the header
            if hasattr(self, "device_list"):
                self.device_list.clear()
                devices = []
                for line in lines:
                    if "device" in line and "unauthorized" not in line:
                        device_id = line.split()[0]
                        model_match = re.search(r"model:(\S+)", line)
                        model = model_match.group(1) if model_match else "Unknown Model"
                        devices.append(f"{device_id} - {model}")
                if devices:
                    self.device_list.addItems(devices)
                    if hasattr(self, "adb_status_label"):
                        self.adb_status_label.setText("ADB Device(s) Detected.")
                        self.adb_indicator_label.setStyleSheet("background-color: green; border-radius: 10px;")
                else:
                    if hasattr(self, "adb_status_label"):
                        self.adb_status_label.setText("No ADB Device Detected.")
                    if hasattr(self, "device_list"):
                        self.device_list.addItem("No devices found")
                    if hasattr(self, "adb_indicator_label"):
                        self.adb_indicator_label.setStyleSheet("background-color: red; border-radius: 10px;")
        except Exception as e:
            if hasattr(self, "adb_status_label"):
                self.adb_status_label.setText(f"Error: {str(e)}")

    def append_output(self, message, color="white", weight="normal"):
        """Append colored and formatted output to Section 1."""
        formatted_message = f'<span style="color:{color}; font-weight:{weight};">{message}</span>'
        self.output_text_edit.append(formatted_message)
        self.output_text_edit.verticalScrollBar().setValue(self.output_text_edit.verticalScrollBar().maximum())

    def icon_path(self, name):
        """Resolve the icon path."""
        return os.path.join(os.path.dirname(__file__), "icon", name)



from datetime import datetime
from pathlib import Path
import os
import json
from PyQt6.QtCore import QThread, pyqtSignal

import os
import subprocess
from PyQt6.QtCore import QThread, pyqtSignal




class PhyReaderThread(QThread):
    log_line = pyqtSignal(str)  # Signal to emit each line of output
    finished=pyqtSignal()
    def __init__(self, command):
        super().__init__()
        self.command = command

    def run(self):
        """Run the command and emit output line by line."""
        try:
            process = subprocess.Popen(
                self.command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True
            )

            for line in process.stdout:
                self.log_line.emit(line)

            process.wait()
            self.finished.emit()
        except Exception as e:
            self.log_line.emit(f"[ERROR] {str(e)}")


class AndroidPhysicalWidget(QtWidgets.QWidget):
    def __init__(self, mount_point, parent=None):
        super().__init__(parent)
        self.mount_point=mount_point

        self.setup_ui()
        self.start_adb_check_timer()
    def image_device_physically(self):
        """Run a script to image the selected device physically."""
        selected_device = self.device_list.currentText()
        if not selected_device or selected_device == "No devices found":
            QMessageBox.warning(self, "No Device Selected", "Please select a valid device to image.")
            return
        if not os.path.exists(self.mount_point):
            QMessageBox.critical(self, "Error", f"Mount point {self.mount_point} does not exist.")
            return

        # Ensure primary storage is set


        # Extract device ID from the selected text
        self.device_id = selected_device.split(" - ")[0]  # Assuming format: "device_id - model_name"

        # Get the primary storage mount point
                # Prepare the command with the output directory as an argument
        command = ["sudo", "bash","/root/Desktop/XPloiter/bin/physical.sh", self.device_id, self.mount_point]

        try:
            # Start the LogReaderThread to run the command
            self.phy_reader_thread = PhyReaderThread(command)
            self.phy_reader_thread.log_line.connect(self.append_output)
            self.phy_reader_thread.start()
            self.phy_reader_thread.finished.connect(self.analyze_data)

            # Inform the user that imaging has started
            QMessageBox.information(self, "Imaging Started",
                                    f"Physical imaging for device {self.device_id} started.\n")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to start physical imaging: {e}")



    def clear_layout(self, layout):
        """Recursively clear all items in a layout."""
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()  # Delete widgets like labels, buttons, etc.
            elif item.layout():
                self.clear_layout(item.layout())  # Recursively clear nested layouts







    def analyze_data(self):
        """Display the extracted report in a futuristic layout."""
        if not os.path.exists(self.mount_point):
            QMessageBox.critical(self, "Error", f"Mount point {self.mount_point} does not exist.")
            return
        # Extract device_id
        DEVICE_ID = self.device_list.currentText().split(" - ")[0].strip()
        report_path = os.path.join(self.mount_point,"Physical", f"{DEVICE_ID}_artifacts", "artifact_report.txt")

        if not os.path.exists(report_path):
            self.append_output(f"[ERROR] Report file {report_path} does not exist.\n", "red", "bold")
            return

        # Clear the main layout and display the report
        self.clear_layout(self.main_layout)

        # Add a title for the report
        title_label = QtWidgets.QLabel("Artifact Analysis Report")
        title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet("""
            font: bold 24px 'Consolas';
            color: #00FFCC;
            background-color: transparent;
            margin: 10px;
        """)
        self.main_layout.addWidget(title_label, stretch=1)

        # Report content area
        report_text_edit = TouchScrollableTextEdit()
        report_text_edit.setReadOnly(True)
        report_text_edit.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                color: #E0E0E0;
                font: 14px 'Courier New';
                border: 1px solid #3E3E5E;
                padding: 10px;
                border-radius: 5px;
            }
        """)

        # Load and display the report content
        try:
            with open(report_path, 'r', encoding='utf-8') as file:
                report_content = file.read()
                report_text_edit.setPlainText(report_content)
                self.append_output(f"[SUCCESS] Report loaded successfully from {report_path}.\n", "green", "bold")
        except Exception as e:
            self.append_output(f"[ERROR] Could not load report: {str(e)}\n", "red", "bold")
            return

        # Add the report content to the layout
        self.main_layout.addWidget(report_text_edit)











    def display_analysis_line(self, line):
        """Display individual analysis lines in the report."""
        line_label = QtWidgets.QLabel(line)
        line_label.setStyleSheet("""
            font: 14px 'Courier New';
            color: #E0E0E0;
            background-color: #1A1A2A;
            padding: 8px;
            border: 1px solid #3E3E5E;
            border-radius: 5px;
            margin: 5px 0;
        """)
        self.analysis_layout.addWidget(line_label)

    def display_full_report(self, output_path):
        """Display the full analysis report in a pretty-printed format inside the frame."""
        try:
            # Read the JSON file
            with open(output_path, 'r', encoding='utf-8') as f:
                report = json.load(f)

            # Clear existing widgets from the frame layout
            self.clear_layout(self.frame.layout())

            # Title for the report
            title_label = QtWidgets.QLabel("Analysis Report (Pretty-Printed)")
            title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            title_label.setStyleSheet("""
                font: bold 24px 'Consolas';
                color: #00FFCC;
                margin: 20px 0;
            """)
            self.analysis_layout.addWidget(title_label)

            # Pretty-print the JSON data
            pretty_json = json.dumps(report, indent=4, ensure_ascii=False)

            # Display the pretty-printed JSON in a QTextEdit
            json_text_edit = TouchScrollableTextEdit()
            json_text_edit.setReadOnly(True)
            json_text_edit.setText(pretty_json)
            json_text_edit.setStyleSheet("""
                QTextEdit {
                    background-color: #1A1A2A;
                    color: #FFFFFF;
                    font: 14px 'Courier New';
                    border: 1px solid #3E3E5E;
                    padding: 10px;
                    border-radius: 5px;
                }
            """)
            self.analysis_layout.addWidget(json_text_edit)

            self.append_output(f"[SUCCESS] Report displayed successfully from {output_path}.\n", "green", "bold")

        except Exception as e:
            self.append_output(f"[ERROR] Could not display report: {str(e)}\n", "red", "bold")









    def setup_ui(self):
        # Main horizontal layout
        self.main_layout = QtWidgets.QHBoxLayout(self)
        self.main_layout.setContentsMargins(10, 10, 10, 10)
        self.main_layout.setSpacing(10)

        # Create sections
        section0 = self.create_section0()
        section1 = self.create_section1()

        # Add sections to the main layout
        self.main_layout.addWidget(section0, stretch=1)

        # Vertical divider
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.VLine)
        line.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        self.main_layout.addWidget(line)

        self.main_layout.addWidget(section1, stretch=1)
        """Set up the main vertical layout for the widget."""


    def create_section0(self):
        """Create section 0 with Android image, ADB status, and device selection."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)
        section_layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)

        # Add Android image
        android_label = QtWidgets.QLabel()
        android_pixmap = QtGui.QPixmap(self.icon_path("evil-android.png")).scaled(
            200, 200, QtCore.Qt.AspectRatioMode.KeepAspectRatio
        )
        android_label.setPixmap(android_pixmap)
        android_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        section_layout.addWidget(android_label, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        # Horizontal layout for status and indicator
        status_layout = QtWidgets.QHBoxLayout()
        self.adb_status_label = QtWidgets.QLabel("Checking ADB connection...")
        self.adb_status_label.setStyleSheet("font: bold 14px 'Consolas'; color: #00FFCC;")
        status_layout.addWidget(self.adb_status_label)

        self.adb_indicator_label = QtWidgets.QLabel()
        self.adb_indicator_label.setFixedSize(20, 20)
        self.adb_indicator_label.setStyleSheet("background-color: red; border-radius: 10px;")
        status_layout.addWidget(self.adb_indicator_label)

        section_layout.addLayout(status_layout)

        # Add device list dropdown
        self.device_list = QtWidgets.QComboBox()
        self.device_list.setStyleSheet("""
            QComboBox {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
                border-radius: 5px;
            }
            QComboBox QAbstractItemView {
                background-color: #000000;
                color: #FFFFFF;
                border: 1px solid #3E3E5E;
                selection-background-color: #00FFCC;
                selection-color: #000000;
            }
        """)
        self.device_list.currentIndexChanged.connect(self.check_if_device_rooted)
        section_layout.addWidget(self.device_list)

        # Add root status label
        self.root_status_label = QtWidgets.QLabel("Root status: Unknown")
        self.root_status_label.setStyleSheet("font: bold 12px 'Consolas'; color: #FFA500;")  # Default orange
        section_layout.addWidget(self.root_status_label, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        # Add "Image Device Physically" button
        self.image_button = FuturisticPushButton("Image Device Physically")
        self.image_button.setStyleSheet("""
            QPushButton {
                background-color: #3E3E5E;
                border: 1px solid #00FFCC;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 8px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #1E1E2E;
            }
        """)
        self.image_button.clicked.connect(self.image_device_physically)
        section_layout.addWidget(self.image_button, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)
        # Add "Analyze Extracted Data" button
        self.analyze_button = FuturisticPushButton("Analyze Extracted Data")
        self.analyze_button.setStyleSheet("""
            QPushButton {
                background-color: #1E1E2E;
                border: 1px solid #00FFCC;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 8px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #3E3E5E;
            }
        """)
        self.analyze_button.setVisible(False)  # Initially hidden
        self.analyze_button.clicked.connect(self.analyze_data)
        section_layout.addWidget(self.analyze_button, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)


        return section

    def check_if_device_rooted(self):
        """Check if the selected device is rooted."""
        selected_device = self.device_list.currentText()
        if not selected_device or selected_device == "No devices found":
            self.root_status_label.setText("Root status: Unknown")
            self.root_status_label.setStyleSheet("font: bold 12px 'Consolas'; color: #FFA500;")  # Orange for unknown
            return

        device_id = selected_device.split(" - ")[0]  # Extract device ID
        try:
            result = subprocess.run(
                ["adb", "-s", device_id, "shell", "su", "-c", "whoami"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            if "root" in result.stdout.strip():
                self.root_status_label.setText("Root status: Rooted")
                self.root_status_label.setStyleSheet("font: bold 12px 'Consolas'; color: #00FF00;")  # Green for rooted
            else:
                self.root_status_label.setText("Root status: Not Rooted")
                self.root_status_label.setStyleSheet("font: bold 12px 'Consolas'; color: #FF0000;")  # Red for not rooted
        except Exception as e:
            self.root_status_label.setText(f"Root status: Error ({str(e)})")
            self.root_status_label.setStyleSheet("font: bold 12px 'Consolas'; color: #FFA500;")  # Orange for error

    def populate_device_list(self):
        """Populate the QComboBox with connected ADB devices."""
        try:
            result = subprocess.run(["adb", "devices", "-l"], stdout=subprocess.PIPE, text=True)
            lines = result.stdout.strip().split("\n")[1:]  # Skip the header
            
            # Ensure the widget exists before accessing
            if self.device_list is None or self.adb_status_label is None:
                return
            
            self.device_list.clear()

            devices = []
            for line in lines:
                if line.strip():
                    device_id = line.split()[0]
                    model_match = re.search(r"model:(\S+)", line)
                    model = model_match.group(1) if model_match else "Unknown Model"
                    devices.append(f"{device_id} - {model}")

            if devices:
                self.device_list.addItems(devices)
                self.adb_status_label.setText("ADB Device(s) Detected.")
                self.adb_indicator_label.setStyleSheet("background-color: green; border-radius: 10px;")
            else:
                self.device_list.addItem("No devices found")
                self.adb_status_label.setText("No ADB Device Detected.")
                self.adb_indicator_label.setStyleSheet("background-color: red; border-radius: 10px;")

        except Exception as e:
            # Ensure the label exists before updating

            self.append_output(f"[ERROR] Failed to populate device list: {str(e)}\n", "red", "bold")


    def create_section1(self):
        """Create section 1 to display script output."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)

        # Output label
        output_label = QtWidgets.QLabel("Output:....")
        output_label.setStyleSheet("font: bold 14px 'Consolas'; color: #00FFCC;")
        section_layout.addWidget(output_label)

        # Output text area
        self.output_text_edit = TouchScrollableTextEdit()
        self.output_text_edit.setReadOnly(True)
        self.output_text_edit.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                color: #FFFFFF;
                font: 12px 'Consolas';
                border: 1px solid #3E3E5E;
                padding: 5px;
                border-radius: 5px;
            }
        """)
        section_layout.addWidget(self.output_text_edit, stretch=1)

        return section

    def start_adb_check_timer(self):
        """Start a timer to periodically check ADB devices."""
        self.adb_timer = QtCore.QTimer(self)
        self.adb_timer.timeout.connect(self.populate_device_list)
        self.adb_timer.start(3000)  # Check every 3 seconds







    def update_output_window(self):
        """Update the output window dynamically as the script produces output."""
        output = self.process.readAllStandardOutput().data().decode()
        lines = output.strip().split("\n")
        for line in lines:
            if "[SUCCESS]" in line:
                self.append_output(f"{line}\n\n", "green", "bold")
            elif "[ERROR]" in line:
                self.append_output(f"{line}\n\n", "red", "bold")
            elif "[INFO]" in line:
                self.append_output(f"{line}\n\n", "blue", "bold")
            else:
                self.append_output(f"{line}\n\n", "white", "normal")
    def append_output(self, message, color="white", weight="normal"):
        """Append colored and formatted output to Section 1."""
        formatted_message = f'<span style="color:{color}; font-weight:{weight};">{message}</span>'
        self.output_text_edit.append(formatted_message)
        self.output_text_edit.verticalScrollBar().setValue(self.output_text_edit.verticalScrollBar().maximum())


    def process_finished(self):
        """Handle process completion."""
        self.append_output("[INFO] Imaging process completed.\n\n", "green", "bold")



    def icon_path(self, name):
        """Resolve the icon path."""
        return os.path.join(os.path.dirname(__file__), "icon", name)













import subprocess
from PyQt6.QtCore import QThread, pyqtSignal


class AnalysisWorker(QThread):
    output = pyqtSignal(str)  # Signal to emit script output
    finished = pyqtSignal()   # Signal emitted when the worker finishes

    def __init__(self, script_path, output_path, disk_name):
        super().__init__()
        self.script_path = script_path
        self.output_path = output_path
        self.output_dir = f"./results/{disk_name}"
        self.running = True  # Flag to control execution

    def run(self):
        """Run the forensic analysis script."""
        try:
            process = subprocess.Popen(
                ["sudo", "bash", self.script_path, self.output_path, self.output_dir],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1  # Line buffered
            )

            for line in process.stdout:
                if not self.running:
                    process.terminate()
                    break
                self.output.emit(line.strip())

            process.stdout.close()
            return_code = process.wait()

            if return_code == 0 and self.running:
                self.output.emit("[INFO] Analysis completed successfully.")
            elif self.running:
                self.output.emit(f"[ERROR] Analysis failed with return code {return_code}.")

        except Exception as e:
            self.output.emit(f"[ERROR] An error occurred: {str(e)}")
        finally:
            self.finished.emit()

    def stop(self):
        """Stop the worker gracefully."""
        self.running = False


class USBImagerWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.setup_ui()
    def setup_ui(self):
        # Main layout
        self.main_layout = QtWidgets.QVBoxLayout(self)  # Define self.main_layout
        self.main_layout.setContentsMargins(10, 10, 10, 10)
        self.main_layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)

        # Add the XPloiter label at the top
        xploiter_label = QtWidgets.QLabel("XPloiter")
        font = QFont()
        font.setPointSize(16)
        font.setBold(True)
        xploiter_label.setFont(font)
        xploiter_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
        xploiter_label.setStyleSheet("color: #00FFCC; font: bold 16px 'Consolas'; background: transparent;")
        self.main_layout.addWidget(xploiter_label)

        # Horizontal layout for sections
        self.sections_layout = QtWidgets.QHBoxLayout()
        self.sections_layout.setContentsMargins(0, 0, 0, 0)

        # Add two sections divided by a vertical line
        section0 = self.create_section0()  # Drive info and actions
        section1 = self.create_section1()  # Imaging output and progress
        self.sections_layout.addWidget(section0, stretch=1)

        # Vertical divider
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.Shape.VLine)
        line.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
        line.setStyleSheet("background: transparent; border: 1px solid #3E3E5E;")
        self.sections_layout.addWidget(line)

        self.sections_layout.addWidget(section1, stretch=1)
        self.main_layout.addLayout(self.sections_layout)

        # Start periodic USB device check
        self.start_usb_status_update()


    def start_usb_status_update(self):
        """Start periodic updates for USB device detection."""
        self.usb_status_timer = QtCore.QTimer(self)
        self.usb_status_timer.timeout.connect(self.check_removable_drives)
        self.usb_status_timer.start(3000)  # Check every 5 seconds

    def check_removable_drives(self):
        """Check connected drives and update the QComboBox."""
        try:
            result = subprocess.run(
                ["lsblk", "-o", "NAME,MODEL"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                check=True
            )
            block_devices = result.stdout.strip().split("\n")[1:]  # Skip the header line
            self.device_map = {}  # Initialize device_map

            for line in block_devices:
                columns = line.split(maxsplit=1)  # Split into NAME and MODEL
                if len(columns) == 2:
                    name, model = columns
                    self.device_map[model.strip()] = name.strip()

            self.combo_box.clear()
            self.combo_box.addItems(self.device_map.keys())
            self.status_label.setText("Drives Detected")

        except subprocess.CalledProcessError as e:
            self.status_label.setText(f"Error: Command failed with code {e.returncode}")
            self.combo_box.clear()
        except FileNotFoundError:
            self.status_label.setText("Error: lsblk command not found.")
            self.combo_box.clear()
        except Exception as e:
            self.status_label.setText(f"Error: {str(e)}")
            self.combo_box.clear()



    def create_section0(self):
        """Create section to display the pendrive image, dropdown, detailed drive info, and action buttons."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)

        # Add pendrive image at the top
        pendrive_label = QtWidgets.QLabel()
        pendrive_pixmap = QtGui.QPixmap(self.icon_path("pendrive.png")).scaled(100, 100, QtCore.Qt.AspectRatioMode.KeepAspectRatio)
        pendrive_label.setPixmap(pendrive_pixmap)
        pendrive_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        section_layout.addWidget(pendrive_label)

        # Status label
        self.status_label = QtWidgets.QLabel("Plug in USB. Checking...")
        self.status_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.status_label.setStyleSheet("color: #00FFCC; font: bold 12px 'Consolas';")
        section_layout.addWidget(self.status_label)

        # "Connected USB Devices" dropdown menu
        self.combo_box = QtWidgets.QComboBox()
        self.combo_box.setStyleSheet("""
            QComboBox {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
                border-radius: 5px;
            }
        """)
        self.combo_box.currentTextChanged.connect(self.update_drive_info)  # Connect to update_drive_info
        section_layout.addWidget(self.combo_box)

        # Drive info text area (initially empty)
        self.drive_info_text = TouchScrollableTextEdit()
        self.drive_info_text.setReadOnly(True)
        self.drive_info_text.setStyleSheet("""
            QTextEdit {
                background-color: transparent;  /* Transparent background */
                color: blue;  /* Blue text */
                font: 12px 'Consolas';
                border: none;  /* No border for cleaner look */
            }
        """)
        section_layout.addWidget(self.drive_info_text)

        # Image Drive button
        self.image_button = FuturisticPushButton("Image Drive")
        self.image_button.clicked.connect(self.start_imaging)
        self.image_button.setStyleSheet("""
            QPushButton {
                background-color: #3E3E5E;
                border: 1px solid #00FFCC;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
                border-radius: 5px;
            }
        """)
        section_layout.addWidget(self.image_button, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        # Output path label (initially hidden)
        self.output_label = QtWidgets.QLabel("")
        self.output_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.output_label.setStyleSheet("color: #00FFCC; font: bold 12px 'Consolas';")
        self.output_label.setVisible(False)
        section_layout.addWidget(self.output_label)

        # Analyze Image button (initially hidden)
        self.analyze_button = FuturisticPushButton("Analyze Image")
        self.analyze_button.clicked.connect(self.run_analysis)
        self.analyze_button.setStyleSheet("""
            QPushButton {
                background-color: #3E3E5E;
                border: 1px solid #00FFCC;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
                border-radius: 5px;
            }
        """)
        self.analyze_button.setVisible(False)
        section_layout.addWidget(self.analyze_button, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        return section



    def update_drive_info(self, selected_model):
        """Update the drive information text area with detailed info (fdisk and lsblk output)."""
        if selected_model in self.device_map:
            device_name = self.device_map[selected_model]
            drive_info = f'<div style="color: white;"><b>Information for /dev/{device_name}:</b><br><br>'

            # Fetch lsblk output
            try:
                lsblk_output = subprocess.check_output(
                    ["sudo","lsblk", "-o", "NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT", f"/dev/{device_name}"],
                    text=True
                )
                drive_info += "<b>lsblk Output:</b><br>" + lsblk_output.replace("\n", "<br>") + "<br><br>"
            except subprocess.CalledProcessError as e:
                drive_info += f"<b>[ERROR]</b> lsblk failed: {e}<br>"
            except FileNotFoundError:
                drive_info += "<b>[ERROR]</b> lsblk command not found.<br>"

            # Fetch fdisk output
            try:
                fdisk_output = subprocess.check_output(
                    ["sudo","fdisk", "-l", f"/dev/{device_name}"],
                    text=True
                )
                drive_info += "<b>fdisk Output:</b><br>" + fdisk_output.replace("\n", "<br>")
            except subprocess.CalledProcessError as e:
                drive_info += f"<b>[ERROR]</b> fdisk failed: {e}<br>"
            except FileNotFoundError:
                drive_info += "<b>[ERROR]</b> fdisk command not found.<br>"

            drive_info += '</div>'
            self.drive_info_text.setHtml(drive_info)
        else:
            self.drive_info_text.setHtml('<div style="color: white;"><b>No information available for the selected drive.</b></div>')


    def create_section1(self):
        """Create section to display output of the imaging process and add warning indicators."""
        section = QtWidgets.QWidget()
        self.section_layout = QtWidgets.QVBoxLayout(section)
        self.section_layout.setContentsMargins(10, 10, 10, 10)

        # Output text area
        self.output_text = TouchScrollableTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: 12px 'Consolas';
                border-radius: 5px;
            }
        """)
        self.section_layout.addWidget(self.output_text)

        # Add a horizontal layout for the red dot and warning label
        warning_layout = QtWidgets.QHBoxLayout()

        # Red dot using QLabelWithOverlay
        self.red_dot_label = QLabelWithOverlay("", self)
        self.red_dot_label.setFixedSize(20, 20)
        self.red_dot_label.set_overlay("circle")  # Use red blinking circle overlay
        self.red_dot_label.setVisible(False)  # Initially hidden
        warning_layout.addWidget(self.red_dot_label, alignment=QtCore.Qt.AlignmentFlag.AlignLeft)

        # Warning label
        self.warning_label = QtWidgets.QLabel("Warning: Imaging in progress...")
        self.warning_label.setStyleSheet("""
            QLabel {
                color: red;
                font: bold 12px 'Consolas';
            }
        """)
        self.warning_label.setVisible(False)  # Initially hidden
        warning_layout.addWidget(self.warning_label, alignment=QtCore.Qt.AlignmentFlag.AlignLeft)

        self.section_layout.addLayout(warning_layout)

        return section


    def icon_path(self, name):
        """Resolve the icon path."""
        return os.path.join(os.path.dirname(__file__), "icon", name)





    def start_imaging(self):
        """Start the imaging process using dd."""
        selected_model = self.combo_box.currentText()
        if not selected_model:
            QtWidgets.QMessageBox.warning(self, "Error", "No drive selected!")
            return

        disk_name = self.device_map.get(selected_model)
        if not disk_name:
            QtWidgets.QMessageBox.warning(self, "Error", "Selected drive not found!")
            return
        self.disk_name=disk_name
        # Generate a unique image filename
        image_filename = f"{disk_name}_usb.img"
        
        # Create a DDWorker (which is now a QObject subclass)
        self.worker = DDWorker(disk_name, image_filename)

        # Create a QThread from the same QtCore module
        self.thread = QtCore.QThread()

        # Move the worker to the new thread
        self.worker.moveToThread(self.thread)

        # Connect the thread's started signal to the worker's process slot
        self.thread.started.connect(self.worker.process)

        # Connect signals from the worker to your UI slots
        self.worker.progress.connect(self.update_output)
        self.worker.error.connect(self.show_error)
        self.worker.finished.connect(self.on_imaging_finished)

        # Clean up: quit the thread when work is done and delete worker/thread afterward
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)

        # Store the output path for later UI updates
        self.output_path = self.worker.output_path

        # Start the thread
        self.thread.start()

        self.start_red_dot_blinking()


        

    def on_imaging_finished(self):
        """Handle cleanup after imaging is complete and update the UI."""
        # Stop blinking red dot and hide warning label
        self.stop_red_dot_blinking()
        self.warning_label.setVisible(False)

        # Update the output with completion message
        self.update_output("[INFO] Imaging process completed.")

        # Display the output path label
        self.output_label.setText(f"Output saved to: {self.output_path}")
        self.output_label.setVisible(True)
        # Show the Analyze Image button
        self.analyze_button.setVisible(True)

        # Check for deleted files





    def start_red_dot_blinking(self):
        """Start blinking the red dot and show warning label."""
        self.red_dot_label.setVisible(True)
        self.red_dot_label.set_overlay("circle")  # Start blinking circle overlay
        self.warning_label.setVisible(True)

    def stop_red_dot_blinking(self):
        """Stop blinking the red dot and hide warning label."""
        self.red_dot_label.setVisible(False)
        self.warning_label.setVisible(False)



    def update_output(self, message):
        """Update the output in the QTextEdit with colored text."""
        if "[INFO]" in message:
            color = "#00FF00"  # Green for info
        elif "[WARNING]" in message:
            color = "#FFFF00"  # Yellow for warnings
        elif "[ERROR]" in message:
            color = "#FF0000"  # Red for errors
        else:
            color = "#FFFFFF"  # Default white for general output

        # Add the colored message to the QTextEdit
        self.output_text.append(f'<span style="color:{color};">{message}</span>')
        self.output_text.verticalScrollBar().setValue(self.output_text.verticalScrollBar().maximum())





    def run_analysis(self):
        """Run the forensic analysis script in a worker thread and locate the generated image."""
        script_path = "./bin/usb_analysis.sh"
        self.output_text.append("Analysis started")
        # Create a new AnalysisWorker
        disk_name = os.path.basename(self.output_path).split("_")[0]  # Extract sda from sda_usb.img
        self.analysis_worker = AnalysisWorker(script_path, self.output_path, disk_name)


        # Connect signals
        self.analysis_worker.finished.connect(self.on_analysis_finished)
        self.analysis_worker.output.connect(self.update_output)

        # Start the worker
        self.analysis_worker.start()

        # Show warning label and start blinking red dot
        self.warning_label.setVisible(True)
        self.start_red_dot_blinking()






    def on_analysis_finished(self):
        """Handle completion of analysis, display forensic report, and locate the generated image."""
        # Stop blinking red dot and hide warning label
        self.stop_red_dot_blinking()
        self.warning_label.setVisible(False)
        self.usb_status_timer.stop()
        # Clear existing section layout (remove section0 and section1)
        while self.sections_layout.count():
            item = self.sections_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

        # Find the latest report directory and file
        latest_forensic_dir = f"./results/{self.disk_name}"
        report_file = os.path.join(latest_forensic_dir, "forensic_report.txt")

        # Create a full-screen widget for analysis results
        analysis_widget = QtWidgets.QWidget(self)
        analysis_layout = QtWidgets.QVBoxLayout(analysis_widget)
        analysis_layout.setContentsMargins(10, 10, 10, 10)

        # XPloiter title
        title_label = QtWidgets.QLabel("XPloiter - Analysis Results")
        title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet("font: bold 16px 'Consolas'; color: #00FF00;")
        analysis_layout.addWidget(title_label)

        # Forensic report view
        report_text_edit = TouchScrollableTextEdit()
        report_text_edit.setReadOnly(True)
        report_text_edit.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: 12px 'Consolas';
                border-radius: 5px;
                padding: 10px;
            }
        """)
        if report_file and os.path.exists(report_file):
            with open(report_file, "r") as file:
                content = file.read()
                report_text_edit.setHtml(f"<pre style='color: #00FF00;'>{content}</pre>")
        else:
            report_text_edit.setHtml("<b style='color: red;'>Error: Forensic analysis report not found.</b>")
        analysis_layout.addWidget(report_text_edit)

        # Close button
        close_button = QtWidgets.QPushButton("Close")
        close_button.setStyleSheet("""
            QPushButton {
                background-color: #3E3E5E;
                border: 1px solid #00FFCC;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #00FFCC;
                color: #000000;
            }
        """)
        close_button.clicked.connect(lambda: analysis_widget.deleteLater())
        analysis_layout.addWidget(close_button, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        # Add the analysis widget to main layout (in full)
        self.main_layout.addWidget(analysis_widget)




    def show_error(self, error_message):
        """Display error messages in the output section."""
        self.output_text.append(f"Error: {error_message}")

















from PyQt6 import QtCore
import os, subprocess

class DDWorker(QtCore.QObject):
    progress = QtCore.pyqtSignal(str)
    error = QtCore.pyqtSignal(str)
    finished = QtCore.pyqtSignal()

    def __init__(self, disk_name, image_filename, parent=None):
        super().__init__(parent)
        self.disk_name = disk_name
        self.output_path = os.path.join(os.getcwd(), "results", image_filename)

    @QtCore.pyqtSlot()
    def process(self):
        try:
            # Validate inputs
            if not self.disk_name or not self.output_path:
                self.error.emit("Invalid disk name or output path.")
                self.finished.emit()
                return

            # Ensure the results folder exists
            results_folder = os.path.dirname(self.output_path)
            if not os.path.exists(results_folder):
                os.makedirs(results_folder)
                self.progress.emit(f"[INFO] Created output directory: {results_folder}")

            # Build dd command
            command = [
                "sudo",
                "dd",
                f"if=/dev/{self.disk_name}",
                f"of={self.output_path}",
                "bs=4M",
                "status=progress"
            ]
            self.progress.emit(f"[INFO] Starting imaging: {' '.join(command)}")

            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            # Stream stderr for progress updates
            while True:
                line = process.stderr.readline()
                if not line:
                    break
                self.progress.emit(f"[INFO] {line.strip()}")

            process.wait()  # Wait for process to complete

            # Check for errors
            if process.returncode != 0:
                # Get any remaining error message
                _, error_msg = process.communicate()
                self.error.emit(f"[ERROR] dd failed: {error_msg.strip()}")
            else:
                self.progress.emit("[INFO] Imaging completed successfully.")

        except Exception as e:
            self.error.emit(f"[ERROR] {str(e)}")
        finally:
            self.finished.emit()




















class AdvancedScanWorker(QtCore.QThread):
    output_signal = QtCore.pyqtSignal(str)
    finished_signal = QtCore.pyqtSignal()

    def __init__(self, command, parent=None):
        super().__init__(parent)
        if not isinstance(command, (list, str)):
            raise ValueError("Command must be a list or a string")
        self.command = command
        self.running = True
        self.process = None  # Store the subprocess object

    def run(self):
        try:
            self.process = subprocess.Popen(
                self.command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            while self.running and self.process.poll() is None:
                line = self.process.stdout.readline()
                if line:
                    self.output_signal.emit(line.strip())

            if self.running:
                for line in self.process.stdout:
                    self.output_signal.emit(line.strip())
                for error_line in self.process.stderr:
                    self.output_signal.emit(f"Error: {error_line.strip()}")

            self.process.wait()
        except Exception as e:
            self.output_signal.emit(f"Error: {str(e)}")
        finally:
            self.finished_signal.emit()

    def stop(self):
        """Stop the worker and terminate the subprocess."""
        self.running = False
        if self.process and self.process.poll() is None:
            self.process.terminate()  # Gracefully terminate the subprocess
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()  # Force kill if termination fails



class NetworkMapperWorker(QtCore.QThread):
    output_signal = QtCore.pyqtSignal(str)
    finished_signal = QtCore.pyqtSignal()

    def __init__(self, interface, parent=None):
        super().__init__(parent)
        self.interface = interface
        self.running = True

    def stop(self):
        self.running = False

    def run(self):
        try:
            print(self.interface)
            process = subprocess.Popen(
                ["sudo", "bash", "./bin/ping.sh", self.interface],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1
            )

            for line in iter(process.stdout.readline, ''):
                if not self.running:
                    break
                self.output_signal.emit(line.strip())

            for error_line in process.stderr:
                self.output_signal.emit(f"Error: {error_line.strip()}")

            process.wait()
        except Exception as e:
            self.output_signal.emit(f"Error: {str(e)}")
        finally:
            self.output_signal.emit("Ping sweep finished.")
            self.finished_signal.emit()







class NetworkMapperWidget(QtWidgets.QWidget):
    """Widget to display network mapping."""
    def __init__(self, selected_interface, parent=None):
        super().__init__(parent)
        self.selected_interface = selected_interface.lower()
        self.layout = QtWidgets.QVBoxLayout(self)
        self.layout.setContentsMargins(10, 10, 10, 10)
        self.layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)
        
        # Label to display the selected interface
        self.selected_interface_label = QtWidgets.QLabel(f"Selected interface: {self.selected_interface}")
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        self.selected_interface_label.setFont(font)
        self.selected_interface_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
        self.selected_interface_label.setStyleSheet("color: #00FFCC; font: bold 14px 'Consolas';")
        self.layout.addWidget(self.selected_interface_label)
        
        # Output display for script results
        self.script_output_text = TouchScrollableTextEdit()
        self.script_output_text.setReadOnly(True)
        self.script_output_text.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: 12px 'Consolas';
            }
        """)
        self.layout.addWidget(self.script_output_text)
        
        self.worker = None  # Initialize worker variable


    def start_ping_script(self):
        """Start the ping.sh script using a worker thread."""
        interface_mapping = {"wi-fi": "wlan0", "ethernet": "eth0"}
        interface = interface_mapping.get(self.selected_interface)
        if not interface:
            self.script_output_text.append("Error: Invalid interface selected.")
            return

        # Stop previous worker if running
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.worker.wait()

        # Create and start a new worker
        self.worker = NetworkMapperWorker(interface)
        self.worker.output_signal.connect(self.update_script_output)
        self.worker.finished_signal.connect(self.on_script_finished)

        self.script_output_text.append(f"Starting ping sweep on interface: {interface}...\n")
        self.worker.start()

    def update_script_output(self, output):
        self.script_output_text.append(output)
        self.script_output_text.verticalScrollBar().setValue(
            self.script_output_text.verticalScrollBar().maximum())



    def on_script_finished(self):
        """Handle script completion."""
        self.script_output_text.append("\nPing sweeping completed.\n")

        # Get the script output
        full_script_output = self.script_output_text.toPlainText()

        # Pass the script output to the host mapping section
        hosts_section = self.create_section0_hosts_mapped(full_script_output)
        self.layout.addWidget(hosts_section)

        # Create the advanced scan section
        advanced_scan_section = self.create_section1_advanced_scan()
        self.layout.addWidget(advanced_scan_section)

    def create_section0_hosts_mapped(self, full_script_output):
        """Create section0 with Hosts Mapped label and a themed list widget for found IPs."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)

        # Label at the top
        label = QtWidgets.QLabel("Hosts mapped")
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        label.setFont(font)
        label.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
        label.setStyleSheet("color: #00FFCC; font: bold 14px 'Consolas';")
        section_layout.addWidget(label)

        # List widget to display found hosts
        hosts_list_widget = QtWidgets.QListWidget()
        hosts_list_widget.setStyleSheet("""
            QListWidget {
                background-color: #121212;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                border-radius: 5px;
            }
            QListWidget::item {
                padding: 10px;
                margin: 2px;
            }
            QListWidget::item:hover {
                background-color: #3E3E5E;
                color: #00FFCC;
            }
            QListWidget::item:selected {
                background-color: #3E3E5E;
                color: #00FFCC;
            }
        """)

        # Extract unique IP addresses using regex
        ip_regex = r"\b(?:\d{1,3}\.){3}\d{1,3}\b"
        unique_hosts = sorted(set(re.findall(ip_regex, full_script_output)))

        for ip in unique_hosts:
            hosts_list_widget.addItem(ip)
        self.hosts_list_widget=hosts_list_widget
        section_layout.addWidget(hosts_list_widget)
        return section

    def create_section1_advanced_scan(self):
        """Create section1 with the 'Run Advanced Scan' button, output window, blinking red dot, and warning label."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)

        # Label at the top
        label = QtWidgets.QLabel("Advanced Scanning")
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        label.setFont(font)
        label.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
        label.setStyleSheet("color: #00FFCC; font: bold 14px 'Consolas';")
        section_layout.addWidget(label)

        # Button to run advanced scan
        self.advanced_scan_button = FuturisticPushButton("Run Advanced Scan")
        self.advanced_scan_button.setStyleSheet("""
            QPushButton {
                background-color: #1E1E2E;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #3E3E5E;
                color: #00FFCC;
            }
        """)
        self.advanced_scan_button.clicked.connect(self.run_advanced_scan)
        section_layout.addWidget(self.advanced_scan_button, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)

        # Button to stop advanced scan
        self.stop_scan_button = FuturisticPushButton("Stop Scan")
        self.stop_scan_button.setStyleSheet("""
            QPushButton {
                background-color: #3E3E5E;
                border: 1px solid #7E7E8E;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #5E5E7E;
                color: #FF0000;
            }
        """)
        self.stop_scan_button.clicked.connect(self.stop_advanced_scan)
        self.stop_scan_button.setEnabled(False)  # Initially disabled
        section_layout.addWidget(self.stop_scan_button, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)

        # Output display for script results
        self.script_output_text = TouchScrollableTextEdit()
        self.script_output_text.setReadOnly(True)
        self.script_output_text.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: 12px 'Consolas';
                border-radius: 5px;
            }
        """)
        section_layout.addWidget(self.script_output_text)  # Add the output window to section1

        # Add a blinking red dot for write-blocking processes
        self.red_dot = QtWidgets.QLabel()
        self.red_dot.setFixedSize(20, 20)
        self.red_dot.setStyleSheet("""
            QLabel {
                background-color: red;
                border-radius: 10px;
            }
        """)
        self.red_dot.setVisible(False)  # Initially hidden
        section_layout.addWidget(self.red_dot, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)

        # Add a warning label for the write-blocking process
        self.warning_label = QtWidgets.QLabel("Write blocking process running. Warning...")
        self.warning_label.setStyleSheet("""
            QLabel {
                color: red;
                font: bold 14px 'Consolas';
            }
        """)
        self.warning_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
        self.warning_label.setVisible(False)  # Initially hidden
        section_layout.addWidget(self.warning_label, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)

        return section




    def toggle_red_dot_visibility(self):
        """Toggle the visibility of the red dot."""
        if self.red_dot.isVisible():
            self.red_dot.setVisible(False)
        else:
            self.red_dot.setVisible(True)
    def get_selected_network_type(self):
        """Get the selected network type from the dropdown menu."""
        return self.interface_dropdown.currentText()


    def run_advanced_scan(self):
        """Run the advanced scan using the AdvancedScanWorker."""
        try:
            # Fetch the selected target IP from the QListWidget
            selected_item = self.hosts_list_widget.currentItem()
            if not selected_item:
                raise ValueError("No target IP selected. Please select a target IP from the list.")

            target_ip = selected_item.text()

            # Get the network type from the dropdown menu in Select Interface UI
            if not hasattr(self, "selected_interface") or not self.selected_interface:
                raise ValueError("No network type selected. Please select a network type in 'Select Interface'.")
            
            network_type = self.selected_interface.lower()
            if network_type not in ["ethernet", "wi-fi"]:
                raise ValueError("Invalid network type selected. Must be 'Ethernet' or 'Wi-Fi'.")

            # Check if a scan is already running
            if hasattr(self, "advanced_scan_worker") and self.advanced_scan_worker.isRunning():
                QtWidgets.QMessageBox.warning(self, "Scan in Progress", "An advanced scan is already running.")
                return

            # Clear the output and display the scan start message
            self.script_output_text.clear()
            self.script_output_text.append("Starting advanced scan...\n")

            # Construct the command
            command = ["sudo", "bash", "./bin/nmapAutomator.sh", target_ip, network_type]
            print(f"Running command: {' '.join(command)}")  # Debugging

            # Initialize the worker
            self.advanced_scan_worker = AdvancedScanWorker(command)
            self.advanced_scan_worker.output_signal.connect(self.update_script_output)
            self.advanced_scan_worker.finished_signal.connect(self.cleanup_after_scan)

            # Start the worker
            self.advanced_scan_worker.start()

            # Enable stop button and blinking red dot
            self.advanced_scan_button.setEnabled(False)
            self.stop_scan_button.setEnabled(True)
            self.start_red_dot_blinking()
            self.warning_label.setVisible(True)
        except ValueError as ve:
            self.script_output_text.append(f"Error: {str(ve)}")
        except Exception as e:
            self.script_output_text.append(f"Unexpected Error: {str(e)}")











    def start_red_dot_blinking(self):
        """Start blinking the red dot."""
        self.red_dot_timer = QtCore.QTimer(self)
        self.red_dot_timer.timeout.connect(self.toggle_red_dot_visibility)
        self.red_dot_timer.start(500)  # Blink every 500ms

    def toggle_red_dot_visibility(self):
        """Toggle the visibility of the red dot."""
        self.red_dot.setVisible(not self.red_dot.isVisible())

    def stop_red_dot_blinking(self):
        """Stop blinking the red dot."""
        if hasattr(self, "red_dot_timer"):
            self.red_dot_timer.stop()
            self.red_dot.setVisible(False)



    def stop_advanced_scan(self):
        """Stop the running advanced scan."""
        if hasattr(self, "advanced_scan_worker") and self.advanced_scan_worker.isRunning():
            self.advanced_scan_worker.stop()  # Call the stop method to terminate the process
            self.script_output_text.append("\nScan stopped by user.")
            self.stop_red_dot_blinking()
            self.warning_label.setVisible(False)



    def cleanup_after_scan(self):
        """Cleanup after the advanced scan is finished."""
        if hasattr(self, "advanced_scan_worker") and self.advanced_scan_worker.isRunning():
            self.advanced_scan_worker.stop()
        self.script_output_text.append("\nAdvanced scan completed.")
        self.advanced_scan_button.setEnabled(True)
        self.stop_scan_button.setEnabled(False)
        self.stop_red_dot_blinking()
        self.warning_label.setVisible(False)




    def update_script_output(self, output):
        """Update the QTextEdit with the script output."""
        self.script_output_text.append(output)
        self.script_output_text.verticalScrollBar().setValue(
            self.script_output_text.verticalScrollBar().maximum())






class ShowPasswordInputWorker(QThread):
    show_dialog = pyqtSignal(str)  # Signal to trigger the dialog display
    finished = pyqtSignal()       # Signal to indicate the worker is finished

    def __init__(self, ssid):
        super().__init__()
        self.ssid = ssid

    def run(self):
        """Emit the signal to show the dialog."""
        self.show_dialog.emit(self.ssid)
        self.finished.emit()


class QLabelWithOverlay(QtWidgets.QLabel):
    """Custom QLabel with dynamic overlay drawing for tick or circle indicators."""
    def __init__(self, image_path=None, parent=None):
        super().__init__(parent)
        if image_path:
            self.original_pixmap = QtGui.QPixmap(image_path)  # Load the original image if provided
            self.setPixmap(self.original_pixmap)  # Set it as the pixmap
        self.overlay_type = None  # Overlay type: 'tick' or 'circle'
        self.is_visible = False  # Visibility state for blinking

        # Timer for blinking effect
        self.blink_timer = QtCore.QTimer(self)
        self.blink_timer.timeout.connect(self.toggle_visibility)  # Connect to toggle visibility

    def set_overlay(self, overlay_type):
        """Set the overlay type and start blinking."""
        self.overlay_type = overlay_type
        if overlay_type in ["circle", "tick"]:
            self.blink_timer.start(500)  # Blink every 500ms
        else:
            self.blink_timer.stop()
            self.is_visible = False
        self.update()  # Trigger repaint

    def start_blinking(self):
        """Start the blinking effect."""
        self.blink_timer.start(500)

    def stop_blinking(self):
        """Stop the blinking effect and make the overlay visible."""
        self.blink_timer.stop()
        self.is_visible = True
        self.update()

    def toggle_visibility(self):
        """Toggle the visibility of the overlay for blinking effect."""
        self.is_visible = not self.is_visible
        self.update()  # Trigger repaint

    def paintEvent(self, event):
        """Custom paint event to draw the overlay."""
        super().paintEvent(event)
        if self.overlay_type is None or not self.is_visible:
            return

        painter = QtGui.QPainter(self)
        rect = self.rect()

        if self.overlay_type == "circle":
            # Draw a red blinking circle in the lower-right corner
            painter.setPen(QtGui.QPen(QtGui.QColor("red"), 3))
            painter.setBrush(QtGui.QBrush(QtGui.QColor(255, 0, 0, 100)))  # Semi-transparent fill
            circle_size = 20
            x = rect.width() - circle_size - 10
            y = rect.height() - circle_size - 10
            painter.drawEllipse(x, y, circle_size, circle_size)

        elif self.overlay_type == "tick":
            # Draw a green blinking tick mark in the lower-right corner
            painter.setPen(QtGui.QPen(QtGui.QColor("green"), 4))
            tick_path = QtGui.QPainterPath()
            x = rect.width() - 50  # Offset from right
            y = rect.height() - 30  # Offset from bottom
            tick_path.moveTo(x, y)
            tick_path.lineTo(x + 10, y + 10)  # Midpoint of tick
            tick_path.lineTo(x + 30, y - 10)  # End of tick
            painter.drawPath(tick_path)



















class SelectInterfaceWidget(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QVBoxLayout(self)  # Directly set the layout to self
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)

        # Add the XPloiter label at the top
        xploiter_label = QtWidgets.QLabel("XPloiter")
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setBold(True)
        xploiter_label.setFont(font)
        xploiter_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
        xploiter_label.setStyleSheet("color: #00FFCC; font: bold 16px 'Consolas';")
        layout.addWidget(xploiter_label)

        # Add the Select Interface dropdown menu below the label
        self.interface_dropdown = QtWidgets.QComboBox()
        self.interface_dropdown.addItem("Select Interface")
        self.interface_dropdown.addItems(["Ethernet", "Wi-Fi"])
        self.interface_dropdown.setStyleSheet("""
            QComboBox {
                background-color: #000000;
                border: 2px solid #4A4A6A;
                border-radius: 8px;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
            }
            QComboBox:hover {
                background-color: #1E1E2E;
                border: 2px solid #00FFCC;
                color: #00FFCC;
            }
            QComboBox QAbstractItemView {
                background-color: #000000;
                color: #FFFFFF;
                border: 1px solid #4A4A6A;
                selection-background-color: #00FFCC;
                selection-color: #000000;
            }
        """)
        self.interface_dropdown.currentTextChanged.connect(self.update_selected_interface)

        layout.addWidget(self.interface_dropdown, alignment=QtCore.Qt.AlignmentFlag.AlignHCenter)
        self.selected_interface = None  # Track selected interface

        # Create a horizontal layout for the Ethernet and Wi-Fi sections
        sections_layout = QtWidgets.QHBoxLayout()
        sections_layout.setContentsMargins(0, 0, 0, 0)

        # Add sections and vertical dividers
        for i in range(2):
            if i == 0:
                section = self.create_section0()
            elif i == 1:
                section = self.create_section1()

            sections_layout.addWidget(section, stretch=1)

            # Add a vertical line after each section except the last
            if i < 1:
                line = QtWidgets.QFrame()
                line.setFrameShape(QtWidgets.QFrame.Shape.VLine)
                line.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
                sections_layout.addWidget(line)

        layout.addLayout(sections_layout)

    def update_selected_interface(self, interface):
        """Update selected interface directly."""
        if interface != "Select Interface":
            self.selected_interface = interface


    def show_password_input(self):
        """Display the password input dialog."""
        selected_ap = self.ap_list.currentItem()
        if not selected_ap:
            QtWidgets.QMessageBox.warning(self, "No AP Selected", "Please select an Access Point (AP) to connect.")
            return

        ssid = selected_ap.text()
        self.create_password_dialog(ssid)

    def create_password_dialog(self, ssid):
        """Create and display a dialog to input the Wi-Fi password, with on-screen keyboard."""
        # Create the dialog
        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle(f"Connect to {ssid}")
        dialog.setModal(True)
        dialog_layout = QtWidgets.QVBoxLayout(dialog)

        # Add a label for instructions
        label = QtWidgets.QLabel(f"Enter the password for {ssid}:")
        dialog_layout.addWidget(label)

        # Add a password input field
        password_input = QtWidgets.QLineEdit()
        password_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        dialog_layout.addWidget(password_input)

        # Add dialog buttons
        button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Ok | QtWidgets.QDialogButtonBox.StandardButton.Cancel)
        dialog_layout.addWidget(button_box)

        # Launch on-screen keyboard
        keyboard_process = subprocess.Popen(["onboard"])

        # Handle dialog button clicks
        def handle_connect():
            password = password_input.text()
            if password:
                self.on_password_provided(ssid, password)
                dialog.accept()
            else:
                QtWidgets.QMessageBox.warning(self, "Input Error", "Password cannot be empty.")

        button_box.accepted.connect(handle_connect)
        button_box.rejected.connect(dialog.reject)

        # Close the on-screen keyboard when the dialog is closed
        def close_keyboard():
            if keyboard_process.poll() is None:  # Check if the process is still running
                keyboard_process.terminate()

        dialog.finished.connect(close_keyboard)

        # Show the dialog
        dialog.exec()

    def on_password_provided(self, ssid, password):
        """Handle the password provided by the user."""
        self.connect_to_ap(ssid, password)

    def icon_path(self, name):
        """Resolve the icon path."""
        return os.path.join(os.path.dirname(__file__), "icon", name)
    def create_section0(self):
        """Create Ethernet status display section."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)

        # Upper half for Ethernet status
        upper_half = QtWidgets.QWidget()
        upper_half_layout = QtWidgets.QVBoxLayout(upper_half)
        self.ethernet_status_text = QtWidgets.QLabel("Ethernet: Checking...")
        self.ethernet_status_text.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.ethernet_status_text.setStyleSheet("color: #00FFCC; font: bold 12px 'Consolas';")
        upper_half_layout.addWidget(self.ethernet_status_text)

        self.ethernet_status_label = QLabelWithOverlay(self.icon_path("rj45.png"))
        self.ethernet_status_label.setFixedSize(200, 200)
        upper_half_layout.addWidget(self.ethernet_status_label, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)
        section_layout.addWidget(upper_half, stretch=1)

        # Lower half for Ethernet details
        self.ethernet_info_text = TouchScrollableTextEdit()
        self.ethernet_info_text.setReadOnly(True)
        self.ethernet_info_text.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: 12px 'Consolas';
            }
        """)
        section_layout.addWidget(self.ethernet_info_text, stretch=1)

        self.update_ethernet_status()
        return section

    def create_section1(self):
        """Create Wi-Fi AP scanning and connection section with real-time status updates."""
        section = QtWidgets.QWidget()
        section_layout = QtWidgets.QVBoxLayout(section)
        section_layout.setContentsMargins(10, 10, 10, 10)

        # Upper half for Wi-Fi status
        upper_half = QtWidgets.QWidget()
        upper_half_layout = QtWidgets.QVBoxLayout(upper_half)
        self.wlan_status_text = QtWidgets.QLabel("Wi-Fi Status: Scanning...")
        self.wlan_status_text.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.wlan_status_text.setStyleSheet("color: #00FFCC; font: bold 12px 'Consolas';")
        upper_half_layout.addWidget(self.wlan_status_text)

        self.wifi_image_label = QLabelWithOverlay(self.icon_path("wifi.gif"))
        self.wifi_image_label.setFixedSize(200, 200)
        wifi_movie = QtGui.QMovie(self.icon_path("wifi.gif"))
        wifi_movie.setScaledSize(QtCore.QSize(200, 200))
        self.wifi_image_label.setMovie(wifi_movie)
        wifi_movie.start()
        upper_half_layout.addWidget(self.wifi_image_label, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)
        section_layout.addWidget(upper_half, stretch=1)

        # Lower half for AP list and connection
        lower_half = QtWidgets.QWidget()
        lower_half_layout = QtWidgets.QVBoxLayout(lower_half)
        self.ap_list = QtWidgets.QListWidget()
        self.ap_list.setStyleSheet("""
            QListWidget {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: 12px 'Consolas';
            }
        """)
        lower_half_layout.addWidget(self.ap_list, stretch=2)

        refresh_button = FuturisticPushButton("Refresh")
        refresh_button.clicked.connect(self.scan_aps)
        lower_half_layout.addWidget(refresh_button, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        self.connect_button = FuturisticPushButton("Connect")
        self.connect_button.setStyleSheet("""
            QPushButton {
                background-color: #1E1E2E;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
            }
        """)
        self.connect_button.clicked.connect(self.show_password_input)
        lower_half_layout.addWidget(self.connect_button, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        self.ap_info_text = TouchScrollableTextEdit()
        self.ap_info_text.setReadOnly(True)
        self.ap_info_text.setStyleSheet("""
            QTextEdit {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: 12px 'Consolas';
            }
        """)
        lower_half_layout.addWidget(self.ap_info_text, stretch=2)
        section_layout.addWidget(lower_half, stretch=1)

        # Start periodic Wi-Fi status updates
        self.start_wifi_status_update()

        return section  # Ensure this is the last line of the function
    def update_wifi_status(self):
        """Update the Wi-Fi status and display a blinking overlay for connection state."""
        is_connected = False
        wifi_info = ""

        try:
            # Check if wlan0 is associated with any network using iwconfig
            cmd = ["iwconfig", "wlan0"]
            result = subprocess.check_output(cmd, text=True).strip()
            
            # Parse iwconfig output to check association
            if "ESSID" in result and "Not-Associated" not in result:
                # Extract SSID from the ESSID field
                for line in result.split("\n"):
                    if "ESSID" in line:
                        ssid = line.split("ESSID:")[1].strip().replace('"', '')
                        wifi_info = f"Connected to SSID: {ssid}\nDevice: wlan0"
                        is_connected = True
                        break
            else:
                wifi_info = "No active Wi-Fi connection."

        except subprocess.CalledProcessError:
            wifi_info = "Error: Unable to determine Wi-Fi status."
        except FileNotFoundError:
            wifi_info = "Error: iwconfig not found. Ensure it is installed."

        # Update overlay and information
        if is_connected:
            self.wifi_image_label.set_overlay("tick")  # Green tick overlay for connected state
        else:
            self.wifi_image_label.set_overlay("circle")  # Red dot overlay for disconnected state

        self.wlan_status_text.setText(wifi_info)

    def start_wifi_status_update(self):
        """Start periodic updates for Wi-Fi status."""
        self.wifi_status_timer = QTimer(self)
        self.wifi_status_timer.timeout.connect(self.update_wifi_status)
        self.wifi_status_timer.start(5000)  # Update every 5 seconds

 


    def update_ethernet_status(self):
        """Update the Ethernet status and display driver/NIC information."""
        is_connected = False
        ethernet_info = ""

        # Get stats and addresses of network interfaces
        net_stats = psutil.net_if_stats()
        net_addrs = psutil.net_if_addrs()

        for iface, stats in net_stats.items():
            # Check if the interface is up, running, and an Ethernet interface
            if "Ethernet" in iface or "eth" in iface.lower():
                ethernet_info += f"Adapter Name: {iface}\n"
                ethernet_info += f"Status: {'Up' if stats.isup else 'Down'}\n"
                ethernet_info += f"Speed: {stats.speed} Mbps\n" if stats.speed else "Speed: Unknown\n"

                # Fetch addresses (IP/MAC)
                addresses = net_addrs.get(iface, [])
                for addr in addresses:
                    if addr.family == socket.AF_INET:  # IPv4
                        ethernet_info += f"IPv4 Address: {addr.address}\n"
                        is_connected = True
                    elif addr.family == socket.AF_INET6:  # IPv6
                        ethernet_info += f"IPv6 Address: {addr.address}\n"
                    elif addr.family == psutil.AF_LINK:  # MAC address
                        ethernet_info += f"MAC Address: {addr.address}\n"

                # Fetch driver and NIC details using OS-specific commands
                ethernet_info += self.get_nic_details(iface)
                break  # Only show information for the first Ethernet interface

        # Update the QLabel overlay with the appropriate status
        if is_connected:
            self.ethernet_status_label.set_overlay("tick")
        else:
            self.ethernet_status_label.set_overlay("circle")

        # Update the Ethernet information text
        self.ethernet_info_text.setText(ethernet_info)

    def get_nic_details(self, iface):
        """Fetch NIC details using OS-specific commands."""
        nic_details = ""

        try:
            # Fetch NIC details using ethtool
            cmd = ["ethtool", "-i", iface]
            result = subprocess.check_output(cmd, text=True)
            nic_details += f"NIC Details:\n{result}\n"
        except subprocess.CalledProcessError as e:
            nic_details += f"Error fetching NIC details: {e}\n"
        except FileNotFoundError:
            nic_details += "ethtool command not found. Please ensure it is installed."
        return nic_details


    def scan_aps(self):
        """Scan for available Wi-Fi access points."""
        
        aps = []

        try:
                # Use nmcli to scan for APs
                cmd = ["nmcli", "-t", "-f", "SSID", "dev", "wifi"]
                result = subprocess.check_output(cmd, text=True)
                aps = result.strip().split("\n")
 

        except subprocess.CalledProcessError as e:
            QtWidgets.QMessageBox.critical(None, "Scan Error", f"Error scanning for APs: {e}")
        except FileNotFoundError:
            QtWidgets.QMessageBox.critical(None, "Command Not Found", "Ensure the required tools are installed.")

        # Populate AP list
        self.ap_list.clear()
        if aps:
            self.ap_list.addItems(aps)
        else:
            self.ap_list.addItem("No APs found.")

    def show_password_input(self):
        """Start a thread to display the password input dialog."""
        selected_ap = self.ap_list.currentItem()
        if not selected_ap:
            QtWidgets.QMessageBox.warning(self, "No AP Selected", "Please select an Access Point (AP) to connect.")
            return

        ssid = selected_ap.text()

        # Directly call create_password_dialog (no need for threading here)
        self.create_password_dialog(ssid)

    def connect_to_ap(self, ssid, password):
        try:
            cmd = ["nmcli", "dev", "wifi", "connect", ssid, "password", password]
            subprocess.check_call(cmd)
            print("Connected to {ssid}")
        except subprocess.CalledProcessError as e:
            print(f"Failed to connect: {e}")
import os
import re
import subprocess
from PyQt6 import QtWidgets, QtGui, QtCore
from PyQt6.QtWidgets import QLabel, QMainWindow, QVBoxLayout, QMessageBox, QApplication, QGraphicsOpacityEffect
from PyQt6.QtCore import QPropertyAnimation, QEasingCurve

# Assumed external classes; make sure they are defined/imported in your project:
# - QLabelWithOverlay
# - SimpleMFRC522
# - ADBFunctionWidget
# - COMWidget
# - AndroidLogicalWidget
# - RFIDImagerWidget
# - USBImagerWidget
# - SelectInterfaceWidget
# - NetworkMapperWidget
# - Ui_MainWindow

class DashboardWidget(QtWidgets.QWidget):
    """Dashboard to display the status of various components."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent  # Reference to MainWindow

        # Main layout for the dashboard
        main_layout = QtWidgets.QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(20)

        # Add title label
        title_label = QtWidgets.QLabel("XPloiter Dashboard")
        title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet("""
            QLabel {
                font: bold 20px 'Consolas';
                color: #00FFCC;
                margin-bottom: 20px;
            }
        """)
        main_layout.addWidget(title_label)

        # Grid layout for components
        self.grid_layout = QtWidgets.QGridLayout()
        self.grid_layout.setContentsMargins(10, 10, 10, 10)
        self.grid_layout.setSpacing(20)
        main_layout.addLayout(self.grid_layout)

        # Initialize components and their statuses
        self.components = {
            "Network Interface": {"status": False, "label": None, "icon": None, "check_func": self.check_network_interface},
            "ADB Test": {"status": False, "label": None, "icon": None, "check_func": self.check_adb_test},
            "USB Drives": {"status": False, "label": None, "icon": None, "check_func": self.check_usb_drives},
        }

        # Create UI elements for each component
        self.create_ui()

        # Timer to update statuses periodically
        self.update_timer = QtCore.QTimer(self)
        self.update_timer.timeout.connect(self.update_statuses)
        self.update_timer.start(5000)  # Update every 5 seconds
    def icon_path(self, name):
        """Resolve the icon path."""
        return os.path.join(os.path.dirname(__file__), "icon", name)

    def create_ui(self):
        """Create UI elements for each component with icons."""
        row, col = 0, 0
        for component_name, component in self.components.items():
            # Create a widget for each component
            component_widget = QtWidgets.QWidget()
            component_layout = QtWidgets.QVBoxLayout(component_widget)
            component_layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)

            # Add component icon
            icon_label = QtWidgets.QLabel()
            # Update the icon path as needed (here it uses a local folder "icons")
            icon_path = f"./icon/{component_name.lower().replace(' ', '_')}.png"
            pixmap = QtGui.QPixmap(icon_path)
            if not pixmap.isNull():
                pixmap = pixmap.scaled(100, 100, QtCore.Qt.AspectRatioMode.KeepAspectRatio)
                icon_label.setPixmap(pixmap)
            else:
                icon_label.setText("No Icon")
                icon_label.setStyleSheet("color: #FF0000; font: bold 12px 'Consolas';")
            component_layout.addWidget(icon_label)

            # Add component name label
            name_label = QtWidgets.QLabel(component_name)
            name_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            name_label.setStyleSheet("font: bold 14px 'Consolas'; color: #00FFCC;")
            component_layout.addWidget(name_label)

            # Add dynamic status icon (used to display a tick or circle overlay)
            status_icon = QLabelWithOverlay()
            status_icon.setFixedSize(50, 50)
            component_layout.addWidget(status_icon)

            # Add status text label
            status_label = QtWidgets.QLabel("Not connected")
            status_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
            status_label.setStyleSheet("font: 12px 'Consolas'; color: #FFFFFF;")
            component_layout.addWidget(status_label)

            # Save references for dynamic updates
            component["label"] = status_label
            component["icon"] = status_icon

            # Place the component widget in the grid layout
            self.grid_layout.addWidget(component_widget, row, col)
            col += 1
            if col >= 3:
                col = 0
                row += 1

    def update_statuses(self):
        """Update the statuses of all components."""
        for component_name, component in self.components.items():
            icon = component["icon"]
            if component_name == "USB Drives":
                usb_drives = self.check_usb_drives()
                component["status"] = bool(usb_drives)
                if usb_drives:
                    drive_list = "\n".join(usb_drives)
                    component["label"].setText(f"Connected Drives:\n{drive_list}")
                    icon.set_overlay("tick")
                else:
                    component["label"].setText("No drives connected")
                    icon.set_overlay("circle")

            elif component_name == "ADB Test":
                adb_devices = self.check_adb_test()
                component["status"] = bool(adb_devices)
                if adb_devices:
                    device_list = "\n".join(adb_devices)
                    component["label"].setText(f"Connected Devices:\n{device_list}")
                    icon.set_overlay("tick")
                else:
                    component["label"].setText("No devices connected")
                    icon.set_overlay("circle")

            elif component_name == "RFID Module":
                is_online = self.check_rfid_module()
                component["status"] = is_online
                if is_online:
                    component["label"].setText("RFID Module Online")
                    icon.set_overlay("tick")
                else:
                    component["label"].setText("RFID Module Offline")
                    icon.set_overlay("circle")

            elif component_name == "Network Interface":
                network_info = self.check_network_interface()
                wifi_status = network_info.get("wifi")
                ethernet_status = network_info.get("ethernet")
                component["status"] = bool(wifi_status or ethernet_status)
                if component["status"]:
                    info_text = ""
                    if wifi_status:
                        info_text += f"Wi-Fi: {wifi_status}\n"
                    if ethernet_status:
                        info_text += f"Ethernet: {ethernet_status}\n"
                    component["label"].setText(info_text.strip())
                    icon.set_overlay("tick")
                else:
                    component["label"].setText("Not connected")
                    icon.set_overlay("circle")

    def check_network_interface(self):
        """Check network interface status."""
        network_info = {"wifi": None, "ethernet": None}
        try:
            result = subprocess.check_output(["iwconfig"], text=True).strip()
            if "ESSID" in result and "Not-Associated" not in result:
                for line in result.split("\n"):
                    if "ESSID" in line:
                        essid = line.split("ESSID:")[1].strip().strip('"')
                        network_info["wifi"] = essid

            result = subprocess.check_output(["ip", "addr"], text=True).strip()
            for block in result.split("\n\n"):
                if "eth0" in block:
                    if "state UP" in block:
                        for line in block.split("\n"):
                            if "inet " in line:
                                ip_address = line.split()[1].split("/")[0]
                                network_info["ethernet"] = (
                                    f"Ethernet Connected (IP: {ip_address})"
                                    if ip_address != "127.0.0.1" 
                                    else "Ethernet Not Connected"
                                )
                                break
                    else:
                        network_info["ethernet"] = "Ethernet Not Connected"
            return network_info
        except Exception as e:
            print(f"Error checking network interface: {e}")
            return network_info

    def check_adb_test(self):
        """Check ADB for connected devices."""
        try:
            result = subprocess.run(["adb", "devices"], capture_output=True, text=True)
            if "List of devices attached" in result.stdout:
                devices = [line.split("\t")[0] for line in result.stdout.splitlines()[1:] if line.strip()]
                return devices
            return []
        except Exception as e:
            print(f"Error checking ADB: {e}")
            return []

    def check_usb_drives(self):
        """Check for USB drive partitions."""
        try:
            result = subprocess.run(
                ["lsblk", "-o", "NAME,TYPE,MOUNTPOINT,RM", "-n"],
                capture_output=True,
                text=True,
                check=True
            )
            drives = []
            for line in result.stdout.strip().splitlines():
                parts = line.split()
                if len(parts) >= 3 and "sd" in parts[0] and parts[1] == "part":
                    mount_point = parts[2] if len(parts) > 2 else None
                    if mount_point:
                        drives.append(parts[0])
            return drives
        except subprocess.CalledProcessError as e:
            print(f"[ERROR] Failed to check USB drives: {e.stderr or e}")
            return []
        except Exception as e:
            print(f"[ERROR] Unexpected error checking USB drives: {e}")
            return []

    def check_rfid_module(self):
        """Check RFID module status."""
        try:
            reader = SimpleMFRC522()
            if reader:
                return True
        except Exception as e:
            return False

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setFixedSize(1024, 600)

        # Create a "results" folder in the current working directory
        self.results_folder = os.path.join(os.getcwd(), "results")
        if not os.path.exists(self.results_folder):
            os.makedirs(self.results_folder)

        # Initialize the dashboard
        self.display_dashboard()
        self.widgets = {}  # Dictionary to store dynamically loaded widgets

        # Connect button signals
        self.ui.button_widgets["Select Interface"].clicked.connect(self.handle_select_interface)
        self.ui.button_widgets["Network Mapper"].clicked.connect(self.start_network_mapper)
        self.ui.button_widgets["USB Imager"].clicked.connect(self.display_usb_imager)
        self.ui.button_widgets["Android Logical"].clicked.connect(self.load_android_logical_widget)
        self.ui.button_widgets["ADB live analysis"].clicked.connect(self.load_adb_function_widget)
        self.ui.logo_button.clicked.connect(self.display_dashboard)

    def display_dashboard(self):
        """Display the dashboard."""
        self.clear_frame()
        dashboard_widget = DashboardWidget(self)
        self.add_widget_to_frame_with_effect(dashboard_widget)

    def load_adb_function_widget(self):
        """Load ADBFunctionWidget."""
        if "ADB Functions" not in self.widgets:
            self.clear_frame()
            adb_widget = ADBFunctionWidget(self)
            self.add_widget_to_frame_with_effect(adb_widget)

    def load_android_logical_widget(self):
        """Load AndroidLogicalWidget."""
        if "Android Logical" not in self.widgets:
            self.clear_frame()
            # Pass the results_folder instead of a mount point
            android_widget = AndroidLogicalWidget(parent=self)
            self.add_widget_to_frame_with_effect(android_widget)

    def load_rfid_widget(self):
        """Load RFIDImagerWidget."""
        if "RFID Sucker" not in self.widgets:
            self.clear_frame()
            rfid_widget = RFIDImagerWidget(self)
            self.add_widget_to_frame_with_effect(rfid_widget)

    def display_usb_imager(self):
        """Display USBImagerWidget."""
        if "USB Imager" not in self.widgets:
            self.clear_frame()
            # Pass the results_folder instead of a mount point
            usb_imager_widget = USBImagerWidget(parent=self)
            self.add_widget_to_frame_with_effect(usb_imager_widget)

    def handle_select_interface(self):
        """Display the Select Interface widget."""
        if "Select Interface" not in self.widgets:
            self.clear_frame()
            self.select_widget = SelectInterfaceWidget(self)
            self.add_widget_to_frame_with_effect(self.select_widget)

    def add_widget_to_frame_with_effect(self, widget, duration=1000):
        """Add a widget to the frame with slide-in and fade-in animations."""
        layout = self.ui.frame.layout()
        if layout is None:
            layout = QVBoxLayout(self.ui.frame)
            self.ui.frame.setLayout(layout)

        # Clear any existing widgets
        for i in reversed(range(layout.count())):
            old_widget = layout.itemAt(i).widget()
            if old_widget:
                old_widget.deleteLater()

        layout.addWidget(widget)
        widget.hide()  # Initially hide the widget

        # Set up the fade-in effect
        opacity_effect = QGraphicsOpacityEffect(widget)
        widget.setGraphicsEffect(opacity_effect)
        fade_animation = QPropertyAnimation(opacity_effect, b"opacity")
        fade_animation.setDuration(duration)
        fade_animation.setStartValue(0.0)
        fade_animation.setEndValue(1.0)

        # Set up the slide-in effect
        widget.move(-self.ui.frame.width(), 0)  # Start off-screen to the left
        widget.resize(self.ui.frame.width(), self.ui.frame.height())
        slide_animation = QPropertyAnimation(widget, b"pos")
        slide_animation.setDuration(duration)
        slide_animation.setStartValue(widget.pos())
        slide_animation.setEndValue(self.ui.frame.rect().topLeft())
        slide_animation.setEasingCurve(QEasingCurve.Type.OutCubic)

        # Store animations so they persist
        self.current_slide_animation = slide_animation
        self.current_fade_animation = fade_animation

        widget.show()
        slide_animation.start()
        fade_animation.start()

    def clear_frame(self):
        """Clear all widgets from the main frame."""
        layout = self.ui.frame.layout()
        if layout:
            for i in reversed(range(layout.count())):
                widget = layout.itemAt(i).widget()
                if widget:
                    widget.deleteLater()

    def start_network_mapper(self):
        """Start or restart the Network Mapper."""
        if not hasattr(self, 'select_widget') or not isinstance(self.select_widget, SelectInterfaceWidget):
            QMessageBox.warning(self, "Error", "Please open the 'Select Interface' widget and choose a valid interface!")
            return

        selected_interface = self.select_widget.selected_interface
        if not selected_interface:
            QMessageBox.warning(self, "Error", "Please select a valid interface from the 'Select Interface' dropdown!")
            return

        try:
            self.clear_frame()
            # Pass the results_folder instead of a mount point
            network_mapper_widget = NetworkMapperWidget(selected_interface, parent=self)
            self.add_widget_to_frame_with_effect(network_mapper_widget)
            network_mapper_widget.start_ping_script()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to start Network Mapper: {e}")
            print(f"Error: {e}")

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    app.setApplicationName("XPloiter")
    mainWindow = MainWindow()
    mainWindow.show()
    sys.exit(app.exec())
