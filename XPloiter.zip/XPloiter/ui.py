from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtCore import QPropertyAnimation, QRect, QEasingCurve, pyqtProperty
from PyQt6.QtGui import QColor, QPainter, QPen
from PyQt6.QtWidgets import QWidget, QPushButton
import os








class Ui_MainWindow(object):
    def icon_path(self, name):
        """Resolve the icon path."""
        return os.path.join(os.path.dirname(__file__), "icon", name)

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1024, 600)

        # Set window icon
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(self.icon_path("wireless-router.png")), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        MainWindow.setWindowIcon(icon)

        # Central widget
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        # Main layout (Horizontal)
        self.main_layout = QtWidgets.QHBoxLayout(self.centralwidget)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        # Sidebar (Vertical layout for buttons)
        self.sidebar = QtWidgets.QWidget()
        self.sidebar_layout = QtWidgets.QVBoxLayout(self.sidebar)
        self.sidebar_layout.setContentsMargins(0, 0, 0, 0)
        self.sidebar_layout.setSpacing(10)

        # Logo button at the top-center of the sidebar
        self.logo_button = QtWidgets.QPushButton()
        self.logo_button.setFixedSize(120, 120)
        self.logo_button.setText("")
        logo_icon = QtGui.QIcon()
        logo_icon.addPixmap(
            QtGui.QPixmap(self.icon_path("exploit.png")),
            QtGui.QIcon.Mode.Normal,
            QtGui.QIcon.State.Off
        )
        self.logo_button.setIcon(logo_icon)
        self.logo_button.setIconSize(QtCore.QSize(100, 100))
        self.sidebar_layout.addWidget(
            self.logo_button, alignment=QtCore.Qt.AlignmentFlag.AlignTop | QtCore.Qt.AlignmentFlag.AlignHCenter
        )

        # Sidebar buttons
        self.buttons = [
            ("Select Interface", "network.png"),
            ("Network Mapper", "wireless-router.png"),
            ("Android Logical", "physical.gif"),
            ("ADB live analysis", "adb.png"),
            ("USB Imager", "pendrive.png"),
        ]
        self.button_widgets = {}
        for text, icon_file in self.buttons:
            button = self.create_button(text, icon_file)
            self.sidebar_layout.addWidget(button)
            self.button_widgets[text] = button

        # Add sidebar to the main layout
        self.main_layout.addWidget(self.sidebar, 0)

        # Main frame (Right Section)
        self.frame = QtWidgets.QStackedWidget()
        self.main_layout.addWidget(self.frame, 1)

        # Apply futuristic styling
        self.apply_futuristic_styles(MainWindow)

        # Set central widget
        MainWindow.setCentralWidget(self.centralwidget)

        # Retranslate UI
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        # Dashboard Widget


    def show_dashboard(self):
        """Display the dashboard interface in the frame."""
        self.frame.setCurrentWidget(self.dashboard_widget)
        self.populate_drives()

    def populate_drives(self):
        """Populate the dropdown menu with available external drives."""
        # Example placeholder logic for drive detection
        self.drive_dropdown.clear()
        self.drive_dropdown.addItems(["Drive 1: /media/usb1", "Drive 2: /media/usb2", "Drive 3: /media/usb3"])

    def get_button_style(self):
        """Return the CSS style for buttons."""
        return """
            QPushButton {
                background-color: #1E1E2E;
                border: 2px solid #3E3E5E;
                border-radius: 10px;
                font: bold 14px 'Consolas';
                color: #FFFFFF;
                padding: 8px;
            }
            QPushButton:hover {
                background-color: #3E3E5E;
                color: #00FFCC;
                border: 2px solid #00FFCC;
            }
        """

    def get_dropdown_style(self):
        """Return the CSS style for the dropdown menu."""
        return """
            QComboBox {
                background-color: #1A1A2A;
                border: 1px solid #3E3E5E;
                color: #FFFFFF;
                font: bold 12px 'Consolas';
                padding: 5px;
                border-radius: 5px;
            }
            QComboBox QAbstractItemView {
                background-color: #000000;
                color: #FFFFFF;
                border: 1px solid #3E3E5E;
                selection-background-color: #00FFCC;
                selection-color: #000000;
            }
        """

    def create_button(self, text, icon_file):
        """Utility function to create larger styled QPushButtons with icons."""
        button = QtWidgets.QPushButton()
        button.setText(text)
        button.setIcon(QtGui.QIcon(self.icon_path(icon_file)))
        button.setIconSize(QtCore.QSize(30, 30))  # Increased icon size
        button.setFixedHeight(50)  # Increased button height
        button.setMinimumWidth(200)  # Optional: Set a minimum width for consistent appearance
        button.setStyleSheet(
            """
            QPushButton {
                background-color: #1E1E2E;
                border: 2px solid #3E3E5E;
                border-radius: 10px;
                font: bold 14px 'Consolas';  /* Increased font size */
                color: #FFFFFF;
                padding: 5px;
            }
            QPushButton:hover {
                background-color: #3E3E5E;
                color: #00FFCC;
                border: 2px solid #00FFCC;
            }
            """
        )
        return button

    def apply_futuristic_styles(self, MainWindow):
        """Apply futuristic styling to the entire application."""
        MainWindow.setStyleSheet(
            """
            QMainWindow {
                background-color: #121212;
            }
            QPushButton {
                background-color: #1E1E2E;
                border: 2px solid #3E3E5E;
                border-radius: 10px;
                font: bold 12px 'Consolas';
                color: #FFFFFF;
                padding: 5px;
            }
            QPushButton:hover {
                background-color: #3E3E5E;
                color: #00FFCC;
                border: 2px solid #00FFCC;
            }
            QLabel {
                color: #00FFCC;
                font: bold 14px 'Consolas';
            }
            QTextEdit {
                background-color: #1A1A2A;
                border: 2px solid #3E3E5E;
                color: #FFFFFF;
                font: 12px 'Consolas';
                border-radius: 10px;
            }
            QFrame {
                background-color: rgba(30, 30, 50, 0.9);
                border-radius: 10px;
            }
        """
        )

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "XPloiter"))
